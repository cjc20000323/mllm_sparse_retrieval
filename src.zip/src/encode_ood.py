import json
import os
import pickle
import string
import sys
from contextlib import nullcontext

import numpy as np
import torch
import torch.distributed as dist
import torch.nn as nn
import torch.nn.functional as F
import torch.utils.data as Data

torch.set_printoptions(threshold=sys.maxsize)
from PIL import Image
from nltk import word_tokenize
from nltk.corpus import stopwords
from peft import PeftModel
from tqdm import tqdm
from transformers import (
    HfArgumentParser,
)
from transformers import LlavaProcessor, LlavaForConditionalGeneration, LlavaNextProcessor, \
    LlavaNextForConditionalGeneration, Qwen2_5_VLProcessor, Qwen2_5_VLForConditionalGeneration, AutoModel, \
    AutoProcessor, Qwen3VLProcessor, Qwen3VLForConditionalGeneration

from arguments import PromptRepsLLMDataArguments, ModelArguments
from arguments import TrainingArguments
from dataset import CrossModalRetrievalDataset, ComposedTextImageRetrievalDataset, TextPersonRetrievalDataset
from model import MLLMRetrievalModel
from template import img_prompt, img_prompt_no_special_llava_v1_5, img_prompt_qwen_v2_5, \
    img_prompt_intern_vl_v2_5, llama3_template, task_text_prompts_copy, task_image_prompts_copy, \
    llama3_retrieval_disassemble_image_prompts, llama3_template_image_prefix, llama3_template_content_element, \
    retrieval_disassemble_image_prompts_3_for_concat, \
    retrieval_disassemble_image_prompts_for_concat, img_prompt_for_concat, \
    retrieval_disassemble_image_prompts_7_for_concat, mistral_img_prompt, llava_mistral_template_image_prefix, \
    llava_mistral_template_content_element, \
    llava_mistral_template_fashion_iq_image_prefix, llama3_template_fashion_iq_image_prefix, \
    retrieval_disassemble_image_prompts_fashion_iq_for_concat, fashion_iq_img_prompt_for_concat, \
    llama3_fashion_iq_image_prompt, mistral_fashion_iq_image_prompt, \
    person_retrieval_img_prompt, mistral_person_retrieval_img_prompt, \
    person_retrieval_img_prompt_1, mistral_person_retrieval_img_prompt_1, \
    person_retrieval_img_prompt_for_concat, person_retrieval_img_prompt_for_concat_1, \
    retrieval_disassemble_image_prompts_person_retrieval_for_concat, \
    retrieval_disassemble_image_prompts_person_retrieval_for_concat_1, \
    retrieval_disassemble_image_origin_prompts_person_retrieval_for_concat, mistral_person_retrieval_img_prompt_2, \
    person_retrieval_img_prompt_2, person_retrieval_img_prompt_for_concat_2, \
    retrieval_disassemble_image_prompts_fashion_iq_for_concat_1, img_prompt_qwen_v3, qwen3_img_prompt, \
    qwen2_5_img_prompt, qwen2_5_template_image_prefix, qwen3_template_image_prefix, qwen3_template_content_element, \
    qwen2_5_template_content_element, qwen3_person_retrieval_img_prompt, \
    retrieval_disassemble_image_prompts_1_for_concat, retrieval_disassemble_image_prompts_2_for_concat, \
    retrieval_disassemble_image_prompts_4_for_concat, retrieval_disassemble_image_prompts_6_for_concat, \
    retrieval_disassemble_image_prompts_person_retrieval_1_for_concat, \
    retrieval_disassemble_image_prompts_person_retrieval_2_for_concat, \
    retrieval_disassemble_image_prompts_person_retrieval_3_for_concat, \
    retrieval_disassemble_image_prompts_person_retrieval_4_for_concat, \
    retrieval_disassemble_image_prompts_person_retrieval_6_for_concat, \
    retrieval_disassemble_image_prompts_person_retrieval_7_for_concat, \
    retrieval_disassemble_image_prompts_for_concat_llama_generation, \
    retrieval_disassemble_image_prompts_for_concat_mistral_generation, vicuna_img_prompt,\
    llava_vicuna_template_image_prefix, llava_vicuna_template_content_element, vicuna_person_retrieval_img_prompt, \
    vicuna_person_retrieval_img_prompt_1, vicuna_person_retrieval_img_prompt_2
from utils import load_image


# from fast_pytorch_kmeans import KMeans
# from faiss import Kmeans


def get_filtered_ids(tokenizer):
    filtered_ids = set()
    for token, id in tokenizer.get_vocab().items():
        if token[0] == '▁' or token[0] == ' ':
            token = token[1:]
        if not token.isalpha() and not token.isdigit():
            continue
        if ord('a') <= ord(token[0]) <= ord('z'):
            filtered_ids.add(id)
    return filtered_ids


def filter_token(token):
    if token[0] == 'Ġ' or token[0] == 'ġ':
        token = token[1:]
    '''
    if ord(token[0]) < ord('a') or ord(token[0]) > ord('z'):
        token = token[1:]
    '''
    return token


def get_img_valid_tokens_values(tokenizer, logits, vocab_dict, data_args, filtered_ids, model_args=None, text=None):
    # 这里是想获得图像的离散值，但是图像是没有文本的，所以不能像原来那样获得对应的token_id，那么是取top 10还是最多128呢，我们先最多128吧

    # if len(token_ids_in_text) == 0:  # if no tokens in the text (rare case), we use top 10 tokens
    #     top_k_values, top_k_indices = logits.topk(10, dim=-1)
    #     values = np.rint(top_k_values.cpu().detach().float().numpy() * 100).astype(int)
    #     tokens = [vocab_dict[i.item()] for i in top_k_indices.cpu().detach().float().numpy()]
    # else:
    # 根据原文，他们遵循了SPLADE设置，为了加强logit离散性，只保留最多128个值
    # 这里应该是先获得了logit，然后再来筛选哪些值，正常来说词表所有位置上的logit都很难是0，
    # 但是这里就默认那些没有的单词还有排名128名之后的单词logit为0了
    # TODO： 这里默认选128个了，但是文本大多数是没有128那么长的，不知道会不会对最终结果有影响
    if text is not None:
        words = [i for i in word_tokenize(text.lower()) if
                 i not in set(stopwords.words('english') + list(string.punctuation))]
        token_ids = set()
        for word in words:
            token_ids.update(tokenizer.encode(word, add_special_tokens=False))
        token_ids_in_text = torch.tensor(list(token_ids))
        top_k = min(len(token_ids_in_text), 128)
        top_k_values, top_k_indices = logits.topk(top_k, dim=-1)
    elif data_args.sparse_manual:
        top_k_values, top_k_indices = logits.topk(data_args.image_sparse_length, dim=-1)
    elif model_args is not None and (
            model_args.eol_type == 'disassembleeol_concrete' or model_args.eol_type == 'disassembleeol_separate'):
        top_k = 30
        top_k_values, top_k_indices = logits.topk(top_k, dim=-1)
    else:
        top_k = data_args.sparse_length
        top_k_values, top_k_indices = logits.topk(top_k, dim=-1)
        if dist.get_rank() == 0:
            if data_args.print_sparse:
                print()
                print([{vocab_dict[indice]: value} for value, indice in
                       zip(top_k_values.tolist(), top_k_indices.tolist())])
    # print(top_k_indices)
    # 原文中说，最后，通过对原始logits值乘以100并进行整数运算实现量化，所得结果表示对应token的权重，这里再四舍五入到最近整数(这是为什么呢)
    values = np.rint(top_k_values.cpu().detach().float().numpy() * 100).astype(int)
    # 把token id换成对应的单词，保存在tokens中
    # e5-v模型会预测出超过词表长度的id，所以过滤一下，这个现象很普遍，目前不知道为什么会预测出这样的结果
    if data_args.is_filtered and data_args.sparse_lower_or_upper == 'lower':
        tokens = [filter_token(vocab_dict[i.item()].lower()) for i in top_k_indices.cpu().detach().float().numpy() if
                  i < len(vocab_dict)]
    elif data_args.sparse_lower_or_upper == 'lower':
        tokens = [vocab_dict[i.item()].lower() for i in top_k_indices.cpu().detach().float().numpy() if
                  i < len(vocab_dict)]
    else:
        tokens = [vocab_dict[i.item()] for i in top_k_indices.cpu().detach().float().numpy() if
                  i < len(vocab_dict)]

    # top tokens not in the text for expansion.
    if data_args.num_expended_tokens > 0:
        token_ids_out_text = torch.tensor(list(filtered_ids - set(top_k_indices)))
        top_k = min(data_args.num_expended_tokens, len(token_ids_out_text))
        top_k_values, top_k_indices = logits[token_ids_out_text].topk(top_k, dim=-1)
        values = np.append(values, np.rint(top_k_values.cpu().detach().float().numpy() * 100).astype(int))
        for i in token_ids_out_text[top_k_indices.cpu().detach().float().numpy()]:
            tokens.append(vocab_dict[i.item()].lower())
    return tokens, values


def get_img_valid_tokens_values_with_cluster(tokenizer, logits, vocab_dict, origin_to_centroids_dict, data_args,
                                             filtered_ids):
    # 这里是想获得图像的离散值，但是图像是没有文本的，所以不能像原来那样获得对应的token_id，那么是取top 10还是最多128呢，我们先最多128吧

    # if len(token_ids_in_text) == 0:  # if no tokens in the text (rare case), we use top 10 tokens
    #     top_k_values, top_k_indices = logits.topk(10, dim=-1)
    #     values = np.rint(top_k_values.cpu().detach().float().numpy() * 100).astype(int)
    #     tokens = [vocab_dict[i.item()] for i in top_k_indices.cpu().detach().float().numpy()]
    # else:
    # 根据原文，他们遵循了SPLADE设置，为了加强logit离散性，只保留最多128个值
    # 这里应该是先获得了logit，然后再来筛选哪些值，正常来说词表所有位置上的logit都很难是0，
    # 但是这里就默认那些没有的单词还有排名128名之后的单词logit为0了
    # TODO： 这里默认选128个了，但是文本大多数是没有128那么长的，不知道会不会对最终结果有影响
    if data_args.sparse_manual:
        top_k_values, top_k_indices = logits.topk(data_args.sparse_length, dim=-1)
    else:
        top_k = 128
        top_k_values, top_k_indices = logits.topk(top_k, dim=-1)
    # print(top_k_indices)
    # 原文中说，最后，通过对原始logits值乘以100并进行整数运算实现量化，所得结果表示对应token的权重，这里再四舍五入到最近整数(这是为什么呢)
    values = np.rint(top_k_values.cpu().detach().float().numpy() * 100).astype(int)
    # 把token id换成对应的单词，保存在tokens中
    tokens = [str(i.item()) for i in top_k_indices.cpu().detach().int().numpy() if
              i < len(vocab_dict)]
    return tokens, values


def get_img_valid_disassemble_tokens_values(tokenizer, disassemble_logits, vocab_dict, data_args, filtered_ids,
                                            logits=None, model_args=None):
    word_set = set()
    word_values = dict()
    if data_args.sparse_manual:
        top_k = data_args.sparse_length
    else:
        top_k = data_args.sparse_length

    top_k_values, top_k_indices = disassemble_logits.topk(top_k, dim=-1)
    for top_k_indice_list in top_k_indices:
        word_set.update(top_k_indice_list.tolist())
    if data_args.print_sparse:
        for top_k_indice_list, top_k_value_list in zip(top_k_indices, top_k_values):
            if dist.get_rank() == 0:
                print(
                    [{vocab_dict[i]: value} for i, value in zip(top_k_indice_list.tolist(), top_k_value_list.tolist())])
    if model_args is not None and (
            model_args.eol_type == 'disassembleeol_separate' or model_args.eol_type == 'all_disassembleeol'
            or model_args.eol_type == 'disassembleeol_separate_origin_text'
            or model_args.eol_type == 'all_disassembleeol_origin_text'):
        values = np.rint(top_k_values.cpu().detach().float().numpy() * 100).astype(int)
        # 下面这里，是通过循环，将五个prompt预测logit结果给拿出来，保存到word_value字典里，先区分大小写，、
        # 在下面构造token和value时会统一转成小写，并在main中的json构造循环里面再次计算sparse_value_type
        for indice_list, value_list in zip(top_k_indices.cpu().detach().float().numpy(), values):
            for indice, value in zip(indice_list, value_list):
                if int(indice.item()) < len(vocab_dict):
                    if vocab_dict[int(indice.item())] in word_values.keys():
                        if int(indice.item()) < len(vocab_dict):
                            if data_args.sparse_value_type == 'replace':
                                word_values[vocab_dict[int(indice.item())]] = value
                            elif data_args.sparse_value_type == 'sum':
                                word_values[vocab_dict[int(indice.item())]] += value
                            else:
                                if value > word_values[vocab_dict[int(indice.item())]]:
                                    word_values[vocab_dict[int(indice.item())]] = value
                    else:
                        if int(indice.item()) < len(vocab_dict):
                            word_values[vocab_dict[int(indice.item())]] = value

    '''
    for disassemble_logit in disassemble_logits:
        top_k_values, top_k_indices = disassemble_logit.topk(top_k, dim=-1)
        word_set.update(top_k_indices.tolist())
        if model_args is not None and (
                model_args.eol_type == 'disassembleeol_separate' or model_args.eol_type == 'all_disassembleeol'
                or model_args.eol_type == 'disassembleeol_separate_origin_text'
                or model_args.eol_type == 'all_disassembleeol_origin_text'):
            values = np.rint(top_k_values.cpu().detach().float().numpy() * 100).astype(int)
            # 下面这里，是通过循环，将五个prompt预测logit结果给拿出来，保存到word_value字典里，先区分大小写，、
            # 在下面构造token和value时会统一转成小写，并在main中的json构造循环里面再次计算sparse_value_type
            for indice, value in zip(top_k_indices.cpu().detach().float().numpy(), values):
                if vocab_dict[int(indice.item())] in word_values.keys():
                    if int(indice.item()) < len(vocab_dict):
                        if data_args.sparse_value_type == 'replace':
                            word_values[vocab_dict[int(indice.item())]] = value
                        elif data_args.sparse_value_type == 'sum':
                            word_values[vocab_dict[int(indice.item())]] += value
                        else:
                            if disassemble_logit[int(indice.item())].cpu().detach() > value:
                                word_values[vocab_dict[int(indice.item())]] = value
                else:
                    if int(indice.item()) < len(vocab_dict):
                        word_values[vocab_dict[int(indice.item())]] = value
    '''

    if model_args is not None and (
            model_args.eol_type == 'disassembleeol_separate' or model_args.eol_type == 'all_disassembleeol'
            or model_args.eol_type == 'disassembleeol_separate_origin_text'
            or model_args.eol_type == 'all_disassembleeol_origin_text'):
        values = [word_values[key] for key in word_values.keys()]
        if data_args.is_filtered and data_args.sparse_lower_or_upper == 'lower':
            tokens = [filter_token(key.lower()) for key in word_values.keys()]
        elif data_args.sparse_lower_or_upper == 'lower':
            tokens = [key.lower() for key in word_values.keys()]
        else:
            tokens = [key for key in word_values.keys()]
    else:
        values = [logits[indice].cpu().detach() for indice in word_set if indice < len(vocab_dict)]
        values = np.rint(np.array(values) * 100).astype(int)

        if data_args.is_filtered and data_args.sparse_lower_or_upper == 'lower':
            tokens = [filter_token(vocab_dict[i].lower()) for i in word_set if i < len(vocab_dict)]
        elif data_args.sparse_lower_or_upper == 'lower':
            tokens = [vocab_dict[i].lower() for i in word_set if i < len(vocab_dict)]
        else:
            tokens = [vocab_dict[i] for i in word_set if i < len(vocab_dict)]
    return tokens, values


def get_img_disassemble_tokens_values_for_information_analysis(tokenizer, disassemble_logits, vocab_dict, data_args,
                                                               filtered_ids,
                                                               logits=None, model_args=None):
    word_set = set()
    word_values = dict()
    if data_args.sparse_manual:
        top_k = data_args.sparse_length
    else:
        top_k = data_args.sparse_length

    top_k_values, top_k_indices = disassemble_logits.topk(top_k, dim=-1)
    for top_k_indice_list in top_k_indices:
        word_set.update(top_k_indice_list.tolist())
    values = np.rint(top_k_values.cpu().detach().float().numpy() * 100).astype(int)
    # 下面这里，是通过循环，将五个prompt预测logit结果给拿出来，保存到word_value字典里，先区分大小写，、
    # 在下面构造token和value时会统一转成小写，并在main中的json构造循环里面再次计算sparse_value_type
    for disassemble_logit in disassemble_logits:
        top_k_values, top_k_indices = disassemble_logit.topk(top_k, dim=-1)
        word_set.update(top_k_indices.tolist())
        values = np.rint(top_k_values.cpu().detach().float().numpy() * 100).astype(int)
        vocabs = []
        for indice in top_k_indices.cpu().detach().float().numpy():
            vocabs.append(vocab_dict[int(indice.item())])


def get_text_valid_tokens_values(text, tokenizer, logits, vocab_dict, data_args, filtered_ids, model_args=None):
    words = [i for i in word_tokenize(text.lower()) if
             i not in set(stopwords.words('english') + list(string.punctuation))]
    token_ids = set()
    for word in words:
        token_ids.update(tokenizer.encode(word, add_special_tokens=False))

    # top tokens in the text
    token_ids_in_text = torch.tensor(list(token_ids))
    if len(token_ids_in_text) == 0:  # if no tokens in the text (rare case), we use top 10 tokens
        top_k_values, top_k_indices = logits.topk(10, dim=-1)
        values = np.rint(top_k_values.cpu().detach().float().numpy() * 100).astype(int)
        if data_args.is_filtered:
            tokens = [filter_token(vocab_dict[i.item()].lower()) for i in top_k_indices.cpu().detach().float().numpy()
                      if
                      i < len(vocab_dict)]
        else:
            tokens = [vocab_dict[i.item()].lower() for i in top_k_indices.cpu().detach().float().numpy() if
                      i < len(vocab_dict)]
    elif data_args.sparse_manual:
        # top_k_values, top_k_indices = logits.topk(len(token_ids_in_text), dim=-1)
        top_k_values, top_k_indices = logits.topk(data_args.text_sparse_length, dim=-1)
        values = np.rint(top_k_values.cpu().detach().float().numpy() * 100).astype(int)
        if data_args.is_filtered and data_args.sparse_lower_or_upper == 'lower':
            tokens = [filter_token(vocab_dict[i.item()].lower()) for i in top_k_indices.cpu().detach().float().numpy()
                      if
                      i < len(vocab_dict)]
        elif data_args.sparse_lower_or_upper == 'lower':
            tokens = [vocab_dict[i.item()].lower() for i in top_k_indices.cpu().detach().float().numpy() if
                      i < len(vocab_dict)]
        else:
            tokens = [vocab_dict[i.item()] for i in top_k_indices.cpu().detach().float().numpy() if
                      i < len(vocab_dict)]
    elif model_args is not None and (
            model_args.eol_type == 'disassembleeol_concrete' or model_args.eol_type == 'disassembleeol_separate'):
        top_k = 30
        top_k_values, top_k_indices = logits.topk(top_k, dim=-1)
        values = np.rint(top_k_values.cpu().detach().float().numpy() * 100).astype(int)
        if data_args.is_filtered and data_args.sparse_lower_or_upper == 'lower':
            tokens = [filter_token(vocab_dict[i.item()].lower()) for i in top_k_indices.cpu().detach().float().numpy()
                      if
                      i < len(vocab_dict)]
        elif data_args.sparse_lower_or_upper == 'lower':
            tokens = [vocab_dict[i.item()].lower() for i in top_k_indices.cpu().detach().float().numpy() if
                      i < len(vocab_dict)]
        else:
            tokens = [vocab_dict[i.item()] for i in top_k_indices.cpu().detach().float().numpy() if
                      i < len(vocab_dict)]
    else:
        # 根据原文，他们遵循了SPLADE设置，为了加强logit离散性，只保留最多128个值
        # 这里应该是先获得了logit，然后再来筛选哪些值，正常来说词表所有位置上的logit都很难是0，
        # 但是这里就默认那些没有的单词还有排名128名之后的单词logit为0了
        top_k = min(len(token_ids_in_text), 128)
        top_k_values, top_k_indices = logits[token_ids_in_text].topk(top_k, dim=-1)
        # 原文中说，最后，通过对原始logits值乘以100并进行整数运算实现量化，所得结果表示对应token的权重，这里再四舍五入到最近整数(这是为什么呢)
        values = np.rint(top_k_values.cpu().detach().float().numpy() * 100).astype(int)
        # 把token id换成对应的单词，保存在tokens中
        if data_args.is_filtered and data_args.sparse_lower_or_upper == 'lower':
            tokens = [filter_token(vocab_dict[i.item()].lower()) for i in
                      token_ids_in_text[top_k_indices.cpu().detach().float().numpy()] if
                      i < len(vocab_dict)]
        elif data_args.sparse_lower_or_upper == 'lower':
            tokens = [vocab_dict[i.item()].lower() for i in
                      token_ids_in_text[top_k_indices.cpu().detach().float().numpy()] if
                      i < len(vocab_dict)]
        else:
            tokens = [vocab_dict[i.item()] for i in
                      token_ids_in_text[top_k_indices.cpu().detach().float().numpy()] if
                      i < len(vocab_dict)]

    # top tokens not in the text for expansion.
    if data_args.num_expended_tokens > 0:
        token_ids_out_text = torch.tensor(list(filtered_ids - token_ids))
        top_k = min(data_args.num_expended_tokens, len(token_ids_out_text))
        top_k_values, top_k_indices = logits[token_ids_out_text].topk(top_k, dim=-1)
        values = np.append(values, np.rint(top_k_values.cpu().detach().float().numpy() * 100).astype(int))
        for i in token_ids_out_text[top_k_indices.cpu().detach().float().numpy()]:
            if data_args.is_filtered:
                tokens.append(filter_token(vocab_dict[i.item()].lower()))
            else:
                tokens.append(vocab_dict[i.item()].lower())
    return tokens, values


def get_text_valid_tokens_values_fusion(text, tokenizer, logits, vocab_dict, data_args, filtered_ids, sparse_type):
    words = [i for i in word_tokenize(text.lower()) if
             i not in set(stopwords.words('english') + list(string.punctuation))]
    token_ids = set()
    for word in words:
        token_ids.update(tokenizer.encode(word, add_special_tokens=False))

    # top tokens in the text
    token_ids_in_text = torch.tensor(list(token_ids))
    if len(token_ids_in_text) == 0:  # if no tokens in the text (rare case), we use top 10 tokens
        top_k_values, top_k_indices = logits.topk(10, dim=-1)
        values = np.rint(top_k_values.cpu().detach().float().numpy() * 100).astype(int)
        if data_args.is_filtered:
            tokens = [filter_token(vocab_dict[i.item()].lower()) for i in top_k_indices.cpu().detach().float().numpy()
                      if
                      i < len(vocab_dict)]
        else:
            tokens = [vocab_dict[i.item()].lower() for i in top_k_indices.cpu().detach().float().numpy() if
                      i < len(vocab_dict)]
    else:
        if sparse_type == 'guess':
            # top_k_values, top_k_indices = logits.topk(len(token_ids_in_text), dim=-1)
            top_k_values, top_k_indices = logits.topk(data_args.text_sparse_length, dim=-1)
            values = np.rint(top_k_values.cpu().detach().float().numpy() * 100).astype(int)
            if data_args.is_filtered and data_args.sparse_lower_or_upper == 'lower':
                tokens = [filter_token(vocab_dict[i.item()].lower()) for i in
                          top_k_indices.cpu().detach().float().numpy()
                          if
                          i < len(vocab_dict)]
            elif data_args.sparse_lower_or_upper == 'lower':
                tokens = [vocab_dict[i.item()].lower() for i in top_k_indices.cpu().detach().float().numpy() if
                          i < len(vocab_dict)]
            else:
                tokens = [vocab_dict[i.item()] for i in top_k_indices.cpu().detach().float().numpy() if
                          i < len(vocab_dict)]
        else:
            # 根据原文，他们遵循了SPLADE设置，为了加强logit离散性，只保留最多128个值
            # 这里应该是先获得了logit，然后再来筛选哪些值，正常来说词表所有位置上的logit都很难是0，
            # 但是这里就默认那些没有的单词还有排名128名之后的单词logit为0了
            top_k = min(len(token_ids_in_text), 128)
            top_k_values, top_k_indices = logits[token_ids_in_text].topk(top_k, dim=-1)
            # 原文中说，最后，通过对原始logits值乘以100并进行整数运算实现量化，所得结果表示对应token的权重，这里再四舍五入到最近整数(这是为什么呢)
            values = np.rint(top_k_values.cpu().detach().float().numpy() * 100).astype(int)
            # 把token id换成对应的单词，保存在tokens中
            if data_args.is_filtered and data_args.sparse_lower_or_upper == 'lower':
                tokens = [filter_token(vocab_dict[i.item()].lower()) for i in
                          token_ids_in_text[top_k_indices.cpu().detach().float().numpy()] if
                          i < len(vocab_dict)]
            elif data_args.sparse_lower_or_upper == 'lower':
                tokens = [vocab_dict[i.item()].lower() for i in
                          token_ids_in_text[top_k_indices.cpu().detach().float().numpy()] if
                          i < len(vocab_dict)]
            else:
                tokens = [vocab_dict[i.item()] for i in
                          token_ids_in_text[top_k_indices.cpu().detach().float().numpy()] if
                          i < len(vocab_dict)]

    # top tokens not in the text for expansion.
    if data_args.num_expended_tokens > 0:
        token_ids_out_text = torch.tensor(list(filtered_ids - token_ids))
        top_k = min(data_args.num_expended_tokens, len(token_ids_out_text))
        top_k_values, top_k_indices = logits[token_ids_out_text].topk(top_k, dim=-1)
        values = np.append(values, np.rint(top_k_values.cpu().detach().float().numpy() * 100).astype(int))
        for i in token_ids_out_text[top_k_indices.cpu().detach().float().numpy()]:
            if data_args.is_filtered:
                tokens.append(filter_token(vocab_dict[i.item()].lower()))
            else:
                tokens.append(vocab_dict[i.item()].lower())
    return tokens, values


def get_text_valid_tokens_values_with_cluster(text, tokenizer, logits, vocab_dict, origin_to_centroids_dict, data_args,
                                              filtered_ids):
    words = [i for i in word_tokenize(text.lower()) if
             i not in set(stopwords.words('english') + list(string.punctuation))]
    token_ids = set()
    for word in words:
        token_encode_ids = tokenizer.encode(word, add_special_tokens=False)
        centroid_ids = [origin_to_centroids_dict[i] for i in token_encode_ids]
        token_ids.update(centroid_ids)

    # top tokens in the text
    token_ids_in_text = torch.tensor(list(token_ids))
    if len(token_ids_in_text) == 0:  # if no tokens in the text (rare case), we use top 10 tokens
        top_k_values, top_k_indices = logits.topk(10, dim=-1)
        values = np.rint(top_k_values.cpu().detach().float().numpy() * 100).astype(int)
        tokens = [str(i.item()) for i in top_k_indices.cpu().detach().int().numpy() if
                  i < len(vocab_dict)]
    elif data_args.sparse_manual:
        top_k_values, top_k_indices = logits.topk(data_args.sparse_length, dim=-1)
        values = np.rint(top_k_values.cpu().detach().float().numpy() * 100).astype(int)
        tokens = [str(i.item()) for i in top_k_indices.cpu().detach().int().numpy() if
                  i < len(vocab_dict)]
    else:
        # 根据原文，他们遵循了SPLADE设置，为了加强logit离散性，只保留最多128个值
        # 这里应该是先获得了logit，然后再来筛选哪些值，正常来说词表所有位置上的logit都很难是0，
        # 但是这里就默认那些没有的单词还有排名128名之后的单词logit为0了
        top_k = min(len(token_ids_in_text), 128)
        top_k_values, top_k_indices = logits[token_ids_in_text].topk(top_k, dim=-1)
        # 原文中说，最后，通过对原始logits值乘以100并进行整数运算实现量化，所得结果表示对应token的权重，这里再四舍五入到最近整数(这是为什么呢)
        values = np.rint(top_k_values.cpu().detach().float().numpy() * 100).astype(int)
        # 把token id换成对应的单词，保存在tokens中
        tokens = [str(int(i.item())) for i in
                  token_ids_in_text[top_k_indices.cpu().detach().float().numpy()] if
                  i < len(vocab_dict)]

    return tokens, values


def get_text_valid_disassemble_tokens_values(text, tokenizer, disassemble_logits, vocab_dict, data_args,
                                             filtered_ids, logits=None, model_args=None):
    word_set = set()
    word_values = dict()
    if data_args.sparse_manual:
        top_k = data_args.sparse_length
    else:
        top_k = data_args.sparse_length
    if model_args is not None and (
            model_args.eol_type == 'disassembleeol_separate_origin_text' or model_args.eol_type == 'all_disassembleeol_origin_text' or model_args.eol_type == 'disassembleeol_concrete_origin_text' or model_args.eol_type == 'all_disassembleeol_concrete_origin_text'):
        words = [i for i in word_tokenize(text.lower()) if
                 i not in set(stopwords.words('english') + list(string.punctuation))]
        token_ids = set()
        for word in words:
            token_ids.update(tokenizer.encode(word, add_special_tokens=False))

        # top tokens in the text
        token_ids_in_text = torch.tensor(list(token_ids))
        top_k = min(len(token_ids_in_text), 128)

    if model_args is not None and (
            model_args.eol_type == 'disassembleeol_separate_origin_text' or model_args.eol_type == 'all_disassembleeol_origin_text'):
        top_k_values, top_k_indices = disassemble_logits[:, token_ids_in_text].topk(top_k, dim=-1)
        values = np.rint(top_k_values.cpu().detach().float().numpy() * 100).astype(int)
        for indice_list, value_list in zip(token_ids_in_text[top_k_indices.cpu().detach().float().numpy()], values):
            for indice, value in zip(indice_list, value_list):
                if int(indice.item()) < len(vocab_dict):
                    if vocab_dict[int(indice.item())] in word_values.keys():
                        if int(indice.item()) < len(vocab_dict):
                            if data_args.sparse_value_type == 'replace':
                                word_values[vocab_dict[int(indice.item())]] = value
                            elif data_args.sparse_value_type == 'sum':
                                word_values[vocab_dict[int(indice.item())]] += value
                            else:
                                if value > word_values[vocab_dict[int(indice.item())]]:
                                    word_values[vocab_dict[int(indice.item())]] = value
                    else:
                        if int(indice.item()) < len(vocab_dict):
                            word_values[vocab_dict[int(indice.item())]] = value
    else:
        top_k_values, top_k_indices = disassemble_logits.topk(top_k, dim=-1)
        for top_k_indice_list in top_k_indices:
            word_set.update(top_k_indice_list.tolist())
        if model_args is not None and (
                model_args.eol_type == 'disassembleeol_separate' or model_args.eol_type == 'all_disassembleeol'):
            values = np.rint(top_k_values.cpu().detach().float().numpy() * 100).astype(int)
            for indice_list, value_list in zip(top_k_indices.cpu().detach().float().numpy(), values):
                for indice, value in zip(indice_list, value_list):
                    if int(indice.item()) < len(vocab_dict):
                        if vocab_dict[int(indice.item())] in word_values.keys():
                            if int(indice.item()) < len(vocab_dict):
                                if data_args.sparse_value_type == 'replace':
                                    word_values[vocab_dict[int(indice.item())]] = value
                                elif data_args.sparse_value_type == 'sum':
                                    word_values[vocab_dict[int(indice.item())]] += value
                                else:
                                    if value > word_values[vocab_dict[int(indice.item())]]:
                                        word_values[vocab_dict[int(indice.item())]] = value
                        else:
                            if int(indice.item()) < len(vocab_dict):
                                word_values[vocab_dict[int(indice.item())]] = value

    if data_args.print_sparse:
        for top_k_indice_list, top_k_value_list in zip(top_k_indices, top_k_values):
            if dist.get_rank() == 2:
                print(
                    [{vocab_dict[i]: value} for i, value in zip(top_k_indice_list.tolist(), top_k_value_list.tolist())])

    '''
    for disassemble_logit in disassemble_logits:
        if model_args is not None and (
                model_args.eol_type == 'disassembleeol_separate_origin_text' or model_args.eol_type == 'all_disassembleeol_origin_text'):
            top_k_values, top_k_indices = disassemble_logit[token_ids_in_text].topk(top_k, dim=-1)
            # 原文中说，最后，通过对原始logits值乘以100并进行整数运算实现量化，所得结果表示对应token的权重，这里再四舍五入到最近整数(这是为什么呢)
            values = np.rint(top_k_values.cpu().detach().float().numpy() * 100).astype(int)
            for indice, value in zip(token_ids_in_text[top_k_indices.cpu().detach().float().numpy()], values):
                if vocab_dict[int(indice.item())] in word_values.keys():
                    if int(indice.item()) < len(vocab_dict):
                        if data_args.sparse_value_type == 'replace':
                            word_values[vocab_dict[int(indice.item())]] = value
                        elif data_args.sparse_value_type == 'sum':
                            word_values[vocab_dict[int(indice.item())]] += value
                        else:
                            if value > word_values[vocab_dict[int(indice.item())]]:
                                word_values[vocab_dict[int(indice.item())]] = value
                else:
                    if int(indice.item()) < len(vocab_dict):
                        word_values[vocab_dict[int(indice.item())]] = value
        else:
            top_k_values, top_k_indices = disassemble_logit.topk(top_k, dim=-1)
            word_set.update(top_k_indices.tolist())
            if model_args is not None and (
                    model_args.eol_type == 'disassembleeol_separate' or model_args.eol_type == 'all_disassembleeol'):
                values = np.rint(top_k_values.cpu().detach().float().numpy() * 100).astype(int)
                for indice, value in zip(top_k_indices.cpu().detach().float().numpy(), values):
                    if vocab_dict[int(indice.item())] in word_values.keys():
                        if int(indice.item()) < len(vocab_dict):
                            if data_args.sparse_value_type == 'replace':
                                word_values[vocab_dict[int(indice.item())]] = value
                            elif data_args.sparse_value_type == 'sum':
                                word_values[vocab_dict[int(indice.item())]] += value
                            else:
                                if value > word_values[vocab_dict[int(indice.item())]]:
                                    word_values[vocab_dict[int(indice.item())]] = value
                    else:
                        if int(indice.item()) < len(vocab_dict):
                            word_values[vocab_dict[int(indice.item())]] = value
    '''

    if model_args is not None and (
            model_args.eol_type == 'disassembleeol_separate' or model_args.eol_type == 'all_disassembleeol'
            or model_args.eol_type == 'disassembleeol_separate_origin_text'
            or model_args.eol_type == 'all_disassembleeol_origin_text'):
        values = [word_values[key] for key in word_values.keys()]
        if data_args.is_filtered and data_args.sparse_lower_or_upper == 'lower':
            tokens = [filter_token(key.lower()) for key in word_values.keys()]
        elif data_args.sparse_lower_or_upper == 'lower':
            tokens = [key.lower() for key in word_values.keys()]
        else:
            tokens = [key for key in word_values.keys()]
    else:
        if model_args is not None and (
                model_args.eol_type == 'disassembleeol_concrete_origin_text' or model_args.eol_type == 'all_disassembleeol_concrete_origin_text'):
            word_set = set(token_ids_in_text.tolist())
        values = [logits[indice].cpu().detach() for indice in word_set if indice < len(vocab_dict)]
        values = np.rint(np.array(values) * 100).astype(int)

        if data_args.is_filtered and data_args.sparse_lower_or_upper == 'lower':
            tokens = [filter_token(vocab_dict[i].lower()) for i in word_set if i < len(vocab_dict)]
        elif data_args.sparse_lower_or_upper == 'lower':
            tokens = [vocab_dict[i].lower() for i in word_set if i < len(vocab_dict)]
        else:
            tokens = [vocab_dict[i] for i in word_set if i < len(vocab_dict)]
    return tokens, values


def get_text_valid_disassemble_tokens_values_fusion(text, tokenizer, disassemble_logits, vocab_dict, data_args,
                                                    filtered_ids, sparse_type, logits=None, model_args=None):
    word_set = set()
    word_values = dict()
    if data_args.sparse_manual:
        top_k = data_args.sparse_length
    else:
        top_k = data_args.sparse_length

    if sparse_type == 'guess':
        top_k_values, top_k_indices = disassemble_logits.topk(top_k, dim=-1)
        for top_k_indice_list in top_k_indices:
            word_set.update(top_k_indice_list.tolist())
        if model_args is not None and ('disassembleeol_concrete' not in model_args.eol_type):
            values = np.rint(top_k_values.cpu().detach().float().numpy() * 100).astype(int)
            for indice_list, value_list in zip(top_k_indices.cpu().detach().float().numpy(), values):
                for indice, value in zip(indice_list, value_list):
                    if int(indice.item()) < len(vocab_dict):
                        if vocab_dict[int(indice.item())] in word_values.keys():
                            if int(indice.item()) < len(vocab_dict):
                                if data_args.sparse_value_type == 'replace':
                                    word_values[vocab_dict[int(indice.item())]] = value
                                elif data_args.sparse_value_type == 'sum':
                                    word_values[vocab_dict[int(indice.item())]] += value
                                else:
                                    if value > word_values[vocab_dict[int(indice.item())]]:
                                        word_values[vocab_dict[int(indice.item())]] = value
                        else:
                            if int(indice.item()) < len(vocab_dict):
                                word_values[vocab_dict[int(indice.item())]] = value

        if model_args is not None and ('disassembleeol_concrete' not in model_args.eol_type):
            values = [word_values[key] for key in word_values.keys()]
            if data_args.is_filtered and data_args.sparse_lower_or_upper == 'lower':
                tokens = [filter_token(key.lower()) for key in word_values.keys()]
            elif data_args.sparse_lower_or_upper == 'lower':
                tokens = [key.lower() for key in word_values.keys()]
            else:
                tokens = [key for key in word_values.keys()]
        else:
            values = [logits[indice].cpu().detach() for indice in word_set if indice < len(vocab_dict)]
            values = np.rint(np.array(values) * 100).astype(int)

            if data_args.is_filtered and data_args.sparse_lower_or_upper == 'lower':
                tokens = [filter_token(vocab_dict[i].lower()) for i in word_set if i < len(vocab_dict)]
            elif data_args.sparse_lower_or_upper == 'lower':
                tokens = [vocab_dict[i].lower() for i in word_set if i < len(vocab_dict)]
            else:
                tokens = [vocab_dict[i] for i in word_set if i < len(vocab_dict)]
        return tokens, values
    else:
        words = [i for i in word_tokenize(text.lower()) if
                 i not in set(stopwords.words('english') + list(string.punctuation))]
        token_ids = set()
        for word in words:
            token_ids.update(tokenizer.encode(word, add_special_tokens=False))

        # top tokens in the text
        token_ids_in_text = torch.tensor(list(token_ids))
        top_k = min(len(token_ids_in_text), 128)

        if model_args is not None and ('disassembleeol_concrete' not in model_args.eol_type):
            top_k_values, top_k_indices = disassemble_logits[:, token_ids_in_text].topk(top_k, dim=-1)
            values = np.rint(top_k_values.cpu().detach().float().numpy() * 100).astype(int)
            for indice_list, value_list in zip(token_ids_in_text[top_k_indices.cpu().detach().float().numpy()], values):
                for indice, value in zip(indice_list, value_list):
                    if int(indice.item()) < len(vocab_dict):
                        if vocab_dict[int(indice.item())] in word_values.keys():
                            if int(indice.item()) < len(vocab_dict):
                                if data_args.sparse_value_type == 'replace':
                                    word_values[vocab_dict[int(indice.item())]] = value
                                elif data_args.sparse_value_type == 'sum':
                                    word_values[vocab_dict[int(indice.item())]] += value
                                else:
                                    if value > word_values[vocab_dict[int(indice.item())]]:
                                        word_values[vocab_dict[int(indice.item())]] = value
                        else:
                            if int(indice.item()) < len(vocab_dict):
                                word_values[vocab_dict[int(indice.item())]] = value

        if model_args is not None and ('disassembleeol_concrete' not in model_args.eol_type):
            values = [word_values[key] for key in word_values.keys()]
            if data_args.is_filtered and data_args.sparse_lower_or_upper == 'lower':
                tokens = [filter_token(key.lower()) for key in word_values.keys()]
            elif data_args.sparse_lower_or_upper == 'lower':
                tokens = [key.lower() for key in word_values.keys()]
            else:
                tokens = [key for key in word_values.keys()]
        else:
            if model_args is not None and ('disassembleeol_concrete' in model_args.eol_type):
                word_set = set(token_ids_in_text.tolist())
            values = [logits[indice].cpu().detach() for indice in word_set if indice < len(vocab_dict)]
            values = np.rint(np.array(values) * 100).astype(int)

            if data_args.is_filtered and data_args.sparse_lower_or_upper == 'lower':
                tokens = [filter_token(vocab_dict[i].lower()) for i in word_set if i < len(vocab_dict)]
            elif data_args.sparse_lower_or_upper == 'lower':
                tokens = [vocab_dict[i].lower() for i in word_set if i < len(vocab_dict)]
            else:
                tokens = [vocab_dict[i] for i in word_set if i < len(vocab_dict)]
        return tokens, values


def get_text_disassemble_tokens_values_for_information_analysis(text, tokenizer, disassemble_logits, vocab_dict,
                                                                data_args,
                                                                filtered_ids, logits=None, model_args=None):
    word_set = set()
    word_values = dict()
    if data_args.sparse_manual:
        top_k = data_args.sparse_length
    else:
        top_k = data_args.sparse_length
    for disassemble_logit in disassemble_logits:
        top_k_values, top_k_indices = disassemble_logit.topk(top_k, dim=-1)
        word_set.update(top_k_indices.tolist())
        values = np.rint(top_k_values.cpu().detach().float().numpy() * 100).astype(int)
        vocabs = []
        for indice in top_k_indices.cpu().detach().float().numpy():
            vocabs.append(vocab_dict[int(indice.item())])


'''
在官方PromptReps中，有一个指定参数是multi_reps，目测是改取最后一个特征和logit为取多个特征和logit，但我们先只考虑取最后一个看看什么情况
有需要的时候再增加multi_reps
'''


def main():
    parser = HfArgumentParser((ModelArguments, PromptRepsLLMDataArguments, TrainingArguments))

    model_args, data_args, training_args = parser.parse_args_into_dataclasses()
    model_args: ModelArguments
    data_args: PromptRepsLLMDataArguments
    training_args: TrainingArguments

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    device_map = "cuda"
    world_size = int(os.environ.get("WORLD_SIZE", 1))
    print(os.environ.get("WORLD_SIZE"))
    ddp = world_size != 1
    print(ddp)
    # if ddp and False:
    if ddp:
        device_map = {"": int(os.environ.get("LOCAL_RANK") or 0)}
        # gradient_accumulation_steps = gradient_accumulation_steps // world_size
        rank, world_size = torch.distributed.get_rank(), torch.distributed.get_world_size()
        if not dist.is_initialized():
            torch.distributed.init_process_group("nccl", rank=rank, device_id=rank)
        rank, world_size = torch.distributed.get_rank(), torch.distributed.get_world_size()
        device_id = rank % torch.cuda.device_count()
        device = torch.device(device_id)
        torch.cuda.set_device(device)

        print(device)

    # 下面这部分指定采用的模型精度
    if training_args.bf16:
        torch_type = torch.bfloat16
    elif training_args.fp16:
        torch_type = torch.float16
    else:
        torch_type = torch.float32

    # 指定模型
    if 'llava-hf-llava-1.5-7b-hf' in model_args.model_name_or_path:
        encoder = LlavaForConditionalGeneration.from_pretrained(model_args.model_name_or_path, device_map=device_map,
                                                                torch_dtype=torch_type)
        processor = LlavaProcessor.from_pretrained(model_args.model_name_or_path)

    elif 'Qwen2.5-VL-7B-Instruct' in model_args.model_name_or_path or 'Qwen2.5-VL-3B-Instruct' in model_args.model_name_or_path:
        encoder = Qwen2_5_VLForConditionalGeneration.from_pretrained(model_args.model_name_or_path,
                                                                     device_map=device_map,
                                                                     torch_dtype=torch_type)
        processor = Qwen2_5_VLProcessor.from_pretrained(model_args.model_name_or_path)

    elif 'Qwen3-VL-8B-Instruct' in model_args.model_name_or_path:
        encoder = Qwen3VLForConditionalGeneration.from_pretrained(model_args.model_name_or_path,
                                                                  device_map=device_map,
                                                                  torch_dtype=torch_type)
        processor = Qwen3VLProcessor.from_pretrained(model_args.model_name_or_path)
    elif 'InternVL2_5-8B' in model_args.model_name_or_path or 'InternVL2_5-4B' in model_args.model_name_or_path:
        # device_map = split_model('InternVL2_5-8B')
        encoder = AutoModel.from_pretrained(model_args.model_name_or_path,
                                            device_map=device_map,
                                            torch_dtype=torch_type,
                                            trust_remote_code=True,
                                            low_cpu_mem_usage=True,
                                            )
        processor = AutoProcessor.from_pretrained(model_args.model_name_or_path,
                                                  trust_remote_code=True, )
    else:
        encoder = LlavaNextForConditionalGeneration.from_pretrained(model_args.model_name_or_path,
                                                                    device_map=device_map,
                                                                    torch_dtype=torch_type)
        processor = LlavaNextProcessor.from_pretrained(model_args.model_name_or_path)
        if 'royokong-e5-v' in model_args.model_name_or_path:
            setattr(processor, "patch_size", 14)  # hack for pass
        conversation = [
            {

                "role": "user",
                "content": [
                    {"type": "text", "text": "\nSummary above image in one word: "},
                    {"type": "image", "image": '{}'},
                ],
            },
        ]
        if 'royokong-e5-v' not in model_args.model_name_or_path:
            prompt = processor.apply_chat_template(conversation, add_generation_prompt=True)
            if dist.get_rank() == 0:
                print(prompt)
            input_id = processor(text=prompt,
                                 return_tensors="pt",
                                 padding=True).input_ids
            if dist.get_rank() == 0:
                print(input_id)

    if data_args.reps_loc == 'after_pad':
        processor.tokenizer.padding_side = "left"
        processor.tokenizer.padding = True
        if dist.get_rank() == 0:
            print(processor.tokenizer.unk_token_id)
            print(processor.tokenizer.eos_token_id)
            print(processor.tokenizer.pad_token_id)

    # 加载词表并获取过滤后的单词id，但目前尚不清楚filtered_ids是做什么的
    if 'InternVL2_5-8B' in model_args.model_name_or_path or 'InternVL2_5-4B' in model_args.model_name_or_path:
        vocab_dict = processor.get_vocab()
        filtered_ids = get_filtered_ids(processor)
    else:
        vocab_dict = processor.tokenizer.get_vocab()
        filtered_ids = get_filtered_ids(processor.tokenizer)
    vocab_dict = {v: k for k, v in vocab_dict.items()}
    print(len(vocab_dict))

    if training_args.encode_type == 'text':
        dataset = CrossModalRetrievalDataset(data_args.dataset_name, processor, data_args.dataset_split, 'full')
        tbpr_dataset = TextPersonRetrievalDataset('CUHK-PEDES', processor, data_args.dataset_split,
                                                  'full')
    else:
        dataset = CrossModalRetrievalDataset(data_args.dataset_name, processor, data_args.dataset_split, 'single')
        tbpr_dataset = TextPersonRetrievalDataset('RSTPReid', processor, data_args.dataset_split,
                                                  'single')

    sampler = Data.DistributedSampler(dataset, num_replicas=dist.get_world_size(), shuffle=True, rank=dist.get_rank())
    tbpr_sampler = Data.DistributedSampler(tbpr_dataset, num_replicas=dist.get_world_size(), shuffle=True, rank=dist.get_rank())
    test_dataloader = Data.DataLoader(dataset=dataset, sampler=sampler, pin_memory=True,
                                      batch_size=data_args.per_device_batch_size, shuffle=False)
    tbpr_test_dataloader = Data.DataLoader(dataset=tbpr_dataset, sampler=tbpr_sampler, pin_memory=True,
                                           batch_size=data_args.per_device_batch_size, shuffle=False)

    model = MLLMRetrievalModel(encoder)
    model = model.eval()
    print(model.is_ddp)

    encoded = []
    jsonl_data = []
    lookup_indices = []

    with torch.no_grad():
        sampler.set_epoch(0)

        for batch_idx, (texts, imgs_path, text_ids, img_ids) in tqdm(enumerate(tbpr_test_dataloader),
                                                                     total=len(tbpr_test_dataloader)):
            text_ids = [id+"000000" for id in text_ids]
            img_ids = [id+"000000" for id in img_ids]

            if 'llava-hf-llava-v1.6-mistral-7b-hf' in model_args.model_name_or_path:
                if data_args.tbpr_type == 'origin_type':
                    prompt_template = llava_mistral_template_image_prefix
                    if 'concrete' in model_args.eol_type or 'all' not in model_args.eol_type:
                        prompt_template += llava_mistral_template_content_element.format(
                            img_prompt_for_concat)
                    for llava_mistral_retrieval_disassemble_image_prompt in retrieval_disassemble_image_origin_prompts_person_retrieval_for_concat:
                        content_element = llava_mistral_template_content_element.format(
                            llava_mistral_retrieval_disassemble_image_prompt)
                        prompt_template += content_element
                elif data_args.tbpr_type == 'type':
                    prompt_template = llava_mistral_template_image_prefix
                    if 'concrete' in model_args.eol_type or 'all' not in model_args.eol_type:
                        prompt_template += llava_mistral_template_content_element.format(
                            person_retrieval_img_prompt_for_concat)
                    if data_args.prompt_type == 'prompt_5':
                        for llava_mistral_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_person_retrieval_for_concat:
                            content_element = llava_mistral_template_content_element.format(
                                llava_mistral_retrieval_disassemble_image_prompt)
                            prompt_template += content_element
                    elif data_args.prompt_type == 'prompt_1':
                        for llava_mistral_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_person_retrieval_1_for_concat:
                            content_element = llava_mistral_template_content_element.format(
                                llava_mistral_retrieval_disassemble_image_prompt)
                            prompt_template += content_element
                    elif data_args.prompt_type == 'prompt_2':
                        for llava_mistral_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_person_retrieval_2_for_concat:
                            content_element = llava_mistral_template_content_element.format(
                                llava_mistral_retrieval_disassemble_image_prompt)
                            prompt_template += content_element
                    elif data_args.prompt_type == 'prompt_3':
                        for llava_mistral_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_person_retrieval_3_for_concat:
                            content_element = llava_mistral_template_content_element.format(
                                llava_mistral_retrieval_disassemble_image_prompt)
                            prompt_template += content_element
                    elif data_args.prompt_type == 'prompt_4':
                        for llava_mistral_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_person_retrieval_4_for_concat:
                            content_element = llava_mistral_template_content_element.format(
                                llava_mistral_retrieval_disassemble_image_prompt)
                            prompt_template += content_element
                    elif data_args.prompt_type == 'prompt_6':
                        for llava_mistral_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_person_retrieval_6_for_concat:
                            content_element = llava_mistral_template_content_element.format(
                                llava_mistral_retrieval_disassemble_image_prompt)
                            prompt_template += content_element
                    elif data_args.prompt_type == 'prompt_7':
                        for llava_mistral_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_person_retrieval_7_for_concat:
                            content_element = llava_mistral_template_content_element.format(
                                llava_mistral_retrieval_disassemble_image_prompt)
                            prompt_template += content_element
                elif data_args.tbpr_type == 'type_1':
                    prompt_template = llava_mistral_template_image_prefix
                    if 'concrete' in model_args.eol_type or 'all' not in model_args.eol_type:
                        prompt_template += llava_mistral_template_content_element.format(
                            person_retrieval_img_prompt_for_concat_1)
                    for llava_mistral_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_person_retrieval_for_concat_1:
                        content_element = llava_mistral_template_content_element.format(
                            llava_mistral_retrieval_disassemble_image_prompt)
                        prompt_template += content_element
                elif data_args.tbpr_type == 'type_2':
                    prompt_template += llava_mistral_template_content_element.format(
                        person_retrieval_img_prompt_for_concat_2)
                    for llava_mistral_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_person_retrieval_for_concat_1:
                        content_element = llava_mistral_template_content_element.format(
                            llava_mistral_retrieval_disassemble_image_prompt)
                        prompt_template += content_element
                else:
                    prompt_template = llava_mistral_template_image_prefix
                    if 'concrete' in model_args.eol_type or 'all' not in model_args.eol_type:
                        prompt_template += llava_mistral_template_content_element.format(
                            img_prompt_for_concat)
                    for llava_mistral_retrieval_disassemble_image_prompt in retrieval_disassemble_image_origin_prompts_person_retrieval_for_concat:
                        content_element = llava_mistral_template_content_element.format(
                            llava_mistral_retrieval_disassemble_image_prompt)
                        prompt_template += content_element
            elif 'llava-hf-llava-v1.6-vicuna-7b-hf' in model_args.model_name_or_path or 'llava-hf-llava-v1.6-vicuna-13b-hf' in model_args.model_name_or_path:
                if data_args.tbpr_type == 'origin_type':
                    prompt_template = llava_vicuna_template_image_prefix
                    if 'concrete' in model_args.eol_type or 'all' not in model_args.eol_type:
                        prompt_template += llava_vicuna_template_content_element.format(
                            img_prompt_for_concat)
                    for llava_vicuna_retrieval_disassemble_image_prompt in retrieval_disassemble_image_origin_prompts_person_retrieval_for_concat:
                        content_element = llava_vicuna_template_content_element.format(
                            llava_vicuna_retrieval_disassemble_image_prompt)
                        prompt_template += content_element
                elif data_args.tbpr_type == 'type':
                    prompt_template = llava_vicuna_template_image_prefix
                    if 'concrete' in model_args.eol_type or 'all' not in model_args.eol_type:
                        prompt_template += llava_vicuna_template_content_element.format(
                            person_retrieval_img_prompt_for_concat)
                    if data_args.prompt_type == 'prompt_5':
                        for llava_vicuna_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_person_retrieval_for_concat:
                            content_element = llava_vicuna_template_content_element.format(
                                llava_vicuna_retrieval_disassemble_image_prompt)
                            prompt_template += content_element
                    elif data_args.prompt_type == 'prompt_1':
                        for llava_vicuna_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_person_retrieval_1_for_concat:
                            content_element = llava_vicuna_template_content_element.format(
                                llava_vicuna_retrieval_disassemble_image_prompt)
                            prompt_template += content_element
                    elif data_args.prompt_type == 'prompt_2':
                        for llava_vicuna_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_person_retrieval_2_for_concat:
                            content_element = llava_vicuna_template_content_element.format(
                                llava_vicuna_retrieval_disassemble_image_prompt)
                            prompt_template += content_element
                    elif data_args.prompt_type == 'prompt_3':
                        for llava_vicuna_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_person_retrieval_3_for_concat:
                            content_element = llava_vicuna_template_content_element.format(
                                llava_vicuna_retrieval_disassemble_image_prompt)
                            prompt_template += content_element
                    elif data_args.prompt_type == 'prompt_4':
                        for llava_vicuna_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_person_retrieval_4_for_concat:
                            content_element = llava_vicuna_template_content_element.format(
                                llava_vicuna_retrieval_disassemble_image_prompt)
                            prompt_template += content_element
                    elif data_args.prompt_type == 'prompt_6':
                        for llava_vicuna_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_person_retrieval_6_for_concat:
                            content_element = llava_vicuna_template_content_element.format(
                                llava_vicuna_retrieval_disassemble_image_prompt)
                            prompt_template += content_element
                    elif data_args.prompt_type == 'prompt_7':
                        for llava_vicuna_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_person_retrieval_7_for_concat:
                            content_element = llava_vicuna_template_content_element.format(
                                llava_vicuna_retrieval_disassemble_image_prompt)
                            prompt_template += content_element
                elif data_args.tbpr_type == 'type_1':
                    prompt_template = llava_vicuna_template_image_prefix
                    if 'concrete' in model_args.eol_type or 'all' not in model_args.eol_type:
                        prompt_template += llava_vicuna_template_content_element.format(
                            person_retrieval_img_prompt_for_concat_1)
                    for llava_vicuna_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_person_retrieval_for_concat_1:
                        content_element = llava_vicuna_template_content_element.format(
                            llava_vicuna_retrieval_disassemble_image_prompt)
                        prompt_template += content_element
                elif data_args.tbpr_type == 'type_2':
                    prompt_template += llava_vicuna_template_content_element.format(
                        person_retrieval_img_prompt_for_concat_2)
                    for llava_vicuna_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_person_retrieval_for_concat_1:
                        content_element = llava_vicuna_template_content_element.format(
                            llava_vicuna_retrieval_disassemble_image_prompt)
                        prompt_template += content_element
                else:
                    prompt_template = llava_vicuna_template_image_prefix
                    if 'concrete' in model_args.eol_type or 'all' not in model_args.eol_type:
                        prompt_template += llava_vicuna_template_content_element.format(
                            img_prompt_for_concat)
                    for llava_vicuna_retrieval_disassemble_image_prompt in retrieval_disassemble_image_origin_prompts_person_retrieval_for_concat:
                        content_element = llava_vicuna_template_content_element.format(
                            llava_vicuna_retrieval_disassemble_image_prompt)
                        prompt_template += content_element
            elif 'Qwen-Qwen3-VL-8B-Instruct' in model_args.model_name_or_path:
                prompt_template = qwen3_template_image_prefix
                if 'concrete' in model_args.eol_type or 'all' not in model_args.eol_type:
                    prompt_template += qwen3_template_content_element.format(
                        person_retrieval_img_prompt_for_concat)
                for qwen3_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_person_retrieval_for_concat:
                    content_element = qwen3_template_content_element.format(
                        qwen3_retrieval_disassemble_image_prompt)
                    prompt_template += content_element
            else:
                if data_args.tbpr_type == 'origin_type':
                    prompt_template = llama3_template_image_prefix
                    if 'concrete' in model_args.eol_type or 'all' not in model_args.eol_type:
                        prompt_template += llama3_template_content_element.format(img_prompt_for_concat)
                    for llama3_retrieval_disassemble_image_prompt in retrieval_disassemble_image_origin_prompts_person_retrieval_for_concat:
                        content_element = llama3_template_content_element.format(
                            llama3_retrieval_disassemble_image_prompt)
                        prompt_template += content_element
                elif data_args.tbpr_type == 'type':
                    prompt_template = llama3_template_image_prefix
                    if 'concrete' in model_args.eol_type or 'all' not in model_args.eol_type:
                        prompt_template += llama3_template_content_element.format(
                            person_retrieval_img_prompt_for_concat)
                    if data_args.prompt_type == 'prompt_5':
                        for llama3_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_person_retrieval_for_concat:
                            content_element = llama3_template_content_element.format(
                                llama3_retrieval_disassemble_image_prompt)
                            prompt_template += content_element
                    elif data_args.prompt_type == 'prompt_1':
                        for llama3_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_person_retrieval_1_for_concat:
                            content_element = llama3_template_content_element.format(
                                llama3_retrieval_disassemble_image_prompt)
                            prompt_template += content_element
                    elif data_args.prompt_type == 'prompt_2':
                        for llama3_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_person_retrieval_2_for_concat:
                            content_element = llama3_template_content_element.format(
                                llama3_retrieval_disassemble_image_prompt)
                            prompt_template += content_element
                    elif data_args.prompt_type == 'prompt_3':
                        for llama3_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_person_retrieval_3_for_concat:
                            content_element = llama3_template_content_element.format(
                                llama3_retrieval_disassemble_image_prompt)
                            prompt_template += content_element
                    elif data_args.prompt_type == 'prompt_4':
                        for llama3_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_person_retrieval_4_for_concat:
                            content_element = llama3_template_content_element.format(
                                llama3_retrieval_disassemble_image_prompt)
                            prompt_template += content_element
                    elif data_args.prompt_type == 'prompt_6':
                        for llama3_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_person_retrieval_6_for_concat:
                            content_element = llama3_template_content_element.format(
                                llama3_retrieval_disassemble_image_prompt)
                            prompt_template += content_element
                    elif data_args.prompt_type == 'prompt_7':
                        for llama3_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_person_retrieval_7_for_concat:
                            content_element = llama3_template_content_element.format(
                                llama3_retrieval_disassemble_image_prompt)
                            prompt_template += content_element
                elif data_args.tbpr_type == 'type_1':
                    prompt_template = llama3_template_image_prefix
                    if 'concrete' in model_args.eol_type or 'all' not in model_args.eol_type:
                        prompt_template += llama3_template_content_element.format(
                            person_retrieval_img_prompt_for_concat_1)
                    for llama3_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_person_retrieval_for_concat_1:
                        content_element = llama3_template_content_element.format(
                            llama3_retrieval_disassemble_image_prompt)
                        prompt_template += content_element
                elif data_args.tbpr_type == 'type_2':
                    prompt_template = llama3_template_image_prefix
                    if 'concrete' in model_args.eol_type or 'all' not in model_args.eol_type:
                        prompt_template += llama3_template_content_element.format(
                            person_retrieval_img_prompt_for_concat_2)
                    for llama3_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_person_retrieval_for_concat_1:
                        content_element = llama3_template_content_element.format(
                            llama3_retrieval_disassemble_image_prompt)
                        prompt_template += content_element
                else:
                    prompt_template = llama3_template_image_prefix
                    if 'concrete' in model_args.eol_type or 'all' not in model_args.eol_type:
                        prompt_template += llama3_template_content_element.format(img_prompt_for_concat)
                    for llama3_retrieval_disassemble_image_prompt in retrieval_disassemble_image_origin_prompts_person_retrieval_for_concat:
                        content_element = llama3_template_content_element.format(
                            llama3_retrieval_disassemble_image_prompt)
                        prompt_template += content_element

            if training_args.encode_type == 'text':
                logits, reps = model.encode_data_concat_for_tbpr(texts, 'text', processor, device, model_args,
                                                        data_args)
                if 'disassembleeol_concrete' in model_args.eol_type:
                    disassemble_logits = logits[data_args.per_device_batch_size:]
                    logits = logits[:data_args.per_device_batch_size]
                elif 'disassembleeol' in model_args.eol_type:
                    disassemble_logits = logits
            else:
                raw_images = [Image.open(path).convert('RGB') for path in imgs_path]
                img_inputs = processor(images=raw_images, text=[prompt_template] * len(imgs_path),
                                       return_tensors="pt",
                                       padding=True)
                imgs = img_inputs.to(device)
                logits, reps = model.encode_data_concat_for_tbpr(imgs, 'image', processor, device, model_args,
                                                        data_args)
                if 'disassembleeol_concrete' in model_args.eol_type:
                    disassemble_logits = logits[data_args.per_device_batch_size:]
                    logits = logits[:data_args.per_device_batch_size]
                elif 'disassembleeol' in model_args.eol_type:
                    disassemble_logits = logits

            # print(logits.shape)
            reps = F.normalize(reps, dim=-1)

            if model_args.eol_type == 'all_disassembleeol' or model_args.eol_type == 'all_disassembleeol_origin_text' or model_args.eol_type == 'all_disassembleeol_concrete' or model_args.eol_type == 'all_disassembleeol_concrete_origin_text':
                prompt_length = 5
                reps = reps.reshape(-1, prompt_length, reps.shape[1]).mean(1)
            if training_args.encode_type == 'text':
                lookup_indices.extend(text_ids)
            else:
                lookup_indices.extend(img_ids)

            encoded.append(reps.cpu().detach().float().numpy())

            ids = text_ids if training_args.encode_type == 'text' else img_ids

            if training_args.encode_type == 'text':
                if data_args.sparse_type == 'fusion':
                    for text_indice in range(len(ids)):
                        id = ids[text_indice]
                        if model_args.eol_type == 'disassembleeol_concrete' or model_args.eol_type == 'disassembleeol_concrete_origin_text' or model_args.eol_type == 'all_disassembleeol_concrete' or model_args.eol_type == 'all_disassembleeol_concrete_origin_text':
                            logit = logits[text_indice]
                        text = texts[text_indice]
                        if data_args.prompt_type == 'prompt_5':
                            length = 5
                        elif data_args.prompt_type == 'prompt_1':
                            length = 1
                        elif data_args.prompt_type == 'prompt_2':
                            length = 2
                        elif data_args.prompt_type == 'prompt_3':
                            length = 3
                        elif data_args.prompt_type == 'prompt_4':
                            length = 4
                        elif data_args.prompt_type == 'prompt_6':
                            length = 6
                        elif data_args.prompt_type == 'prompt_7':
                            length = 7
                        else:
                            length = 5
                        disassemble_logit = disassemble_logits[
                                            text_indice * length:(text_indice + 1) * length]
                        vector = dict()
                        if model_args.eol_type == 'disassembleeol_concrete' or model_args.eol_type == 'disassembleeol_concrete_origin_text' or model_args.eol_type == 'all_disassembleeol_concrete' or model_args.eol_type == 'all_disassembleeol_concrete_origin_text':
                            tokens, values = get_text_valid_disassemble_tokens_values_fusion(text,
                                                                                             processor.tokenizer,
                                                                                             disassemble_logit,
                                                                                             vocab_dict,
                                                                                             data_args,
                                                                                             filtered_ids,
                                                                                             'guess', logit,
                                                                                             model_args)
                        else:
                            tokens, values = get_text_valid_disassemble_tokens_values_fusion(text,
                                                                                             processor.tokenizer,
                                                                                             disassemble_logit,
                                                                                             vocab_dict,
                                                                                             data_args,
                                                                                             filtered_ids,
                                                                                             'guess', None,
                                                                                             model_args)

                        for token, v in zip(tokens, values):
                            if token in vector.keys():
                                if data_args.sparse_value_type == 'replace':
                                    vector[token] = int(v)
                                elif data_args.sparse_value_type == 'sum':
                                    vector[token] += int(v)
                                else:
                                    if int(v) > vector[token]:
                                        vector[token] = int(v)
                            else:
                                vector[token] = int(v)
                        if data_args.sparse_value_mean:
                            for token in vector.keys():
                                if data_args.prompt_type == 'prompt_5':
                                    vector[token] //= 5
                                elif data_args.prompt_type == 'prompt_1':
                                    vector[token] //= 1
                                elif data_args.prompt_type == 'prompt_2':
                                    vector[token] //= 2
                                elif data_args.prompt_type == 'prompt_3':
                                    vector[token] //= 3
                                elif data_args.prompt_type == 'prompt_4':
                                    vector[token] //= 4
                                elif data_args.prompt_type == 'prompt_6':
                                    vector[token] //= 6
                                else:
                                    vector[token] //= 7
                        if model_args.eol_type == 'disassembleeol_concrete' or model_args.eol_type == 'disassembleeol_concrete_origin_text' or model_args.eol_type == 'all_disassembleeol_concrete' or model_args.eol_type == 'all_disassembleeol_concrete_origin_text':
                            tokens, values = get_text_valid_disassemble_tokens_values_fusion(text,
                                                                                             processor.tokenizer,
                                                                                             disassemble_logit,
                                                                                             vocab_dict,
                                                                                             data_args,
                                                                                             filtered_ids,
                                                                                             'origin_text',
                                                                                             logit,
                                                                                             model_args)
                        else:
                            tokens, values = get_text_valid_disassemble_tokens_values_fusion(text,
                                                                                             processor.tokenizer,
                                                                                             disassemble_logit,
                                                                                             vocab_dict,
                                                                                             data_args,
                                                                                             filtered_ids,
                                                                                             'origin_text',
                                                                                             None,
                                                                                             model_args)
                        for token, v in zip(tokens, values):
                            if token in vector.keys():
                                if data_args.sparse_value_type == 'replace':
                                    vector[token] = int(v)
                                elif data_args.sparse_value_type == 'sum':
                                    vector[token] += int(v)
                                else:
                                    if int(v) > vector[token]:
                                        vector[token] = int(v)
                            else:
                                vector[token] = int(v)
                        jsonl_data.append(
                            dict(
                                id=id,
                                content="",
                                vector=vector,
                            )
                        )
                else:
                    for text_indice in range(len(ids)):
                        id = ids[text_indice]
                        if model_args.eol_type == 'disassembleeol_concrete' or model_args.eol_type == 'disassembleeol_concrete_origin_text' or model_args.eol_type == 'all_disassembleeol_concrete' or model_args.eol_type == 'all_disassembleeol_concrete_origin_text':
                            logit = logits[text_indice]
                        text = texts[text_indice]
                        if data_args.prompt_type == 'prompt_5':
                            length = 5
                        elif data_args.prompt_type == 'prompt_1':
                            length = 1
                        elif data_args.prompt_type == 'prompt_2':
                            length = 2
                        elif data_args.prompt_type == 'prompt_3':
                            length = 3
                        elif data_args.prompt_type == 'prompt_4':
                            length = 4
                        elif data_args.prompt_type == 'prompt_6':
                            length = 6
                        elif data_args.prompt_type == 'prompt_7':
                            length = 7
                        else:
                            length = 5
                        disassemble_logit = disassemble_logits[
                                            text_indice * length:(text_indice + 1) * length]
                        vector = dict()
                        if model_args.eol_type == 'disassembleeol_concrete' or model_args.eol_type == 'disassembleeol_concrete_origin_text' or model_args.eol_type == 'all_disassembleeol_concrete' or model_args.eol_type == 'all_disassembleeol_concrete_origin_text':
                            tokens, values = get_text_valid_disassemble_tokens_values(text,
                                                                                      processor.tokenizer,
                                                                                      disassemble_logit,
                                                                                      vocab_dict,
                                                                                      data_args,
                                                                                      filtered_ids, logit,
                                                                                      model_args)
                        else:
                            tokens, values = get_text_valid_disassemble_tokens_values(text,
                                                                                      processor.tokenizer,
                                                                                      disassemble_logit,
                                                                                      vocab_dict,
                                                                                      data_args,
                                                                                      filtered_ids, None,
                                                                                      model_args)

                        for token, v in zip(tokens, values):
                            if token in vector.keys():
                                if data_args.sparse_value_type == 'replace':
                                    vector[token] = int(v)
                                elif data_args.sparse_value_type == 'sum':
                                    vector[token] += int(v)
                                else:
                                    if int(v) > vector[token]:
                                        vector[token] = int(v)
                            else:
                                vector[token] = int(v)
                        if data_args.sparse_value_mean:
                            for token in vector.keys():
                                if data_args.prompt_type == 'prompt_5':
                                    vector[token] //= 5
                                elif data_args.prompt_type == 'prompt_1':
                                    vector[token] //= 1
                                elif data_args.prompt_type == 'prompt_2':
                                    vector[token] //= 2
                                elif data_args.prompt_type == 'prompt_3':
                                    vector[token] //= 3
                                elif data_args.prompt_type == 'prompt_4':
                                    vector[token] //= 4
                                elif data_args.prompt_type == 'prompt_6':
                                    vector[token] //= 6
                                else:
                                    vector[token] //= 7
                        jsonl_data.append(
                            dict(
                                id=id,
                                content="",
                                vector=vector,
                            )
                        )
            else:
                for img_indice in range(len(ids)):
                    id = ids[img_indice]
                    if model_args.eol_type == 'disassembleeol_concrete' or model_args.eol_type == 'disassembleeol_concrete_origin_text' or model_args.eol_type == 'all_disassembleeol_concrete' or model_args.eol_type == 'all_disassembleeol_concrete_origin_text':
                        logit = logits[img_indice]
                    text = texts[img_indice]
                    if data_args.prompt_type == 'prompt_5':
                        length = 5
                    elif data_args.prompt_type == 'prompt_1':
                        length = 1
                    elif data_args.prompt_type == 'prompt_2':
                        length = 2
                    elif data_args.prompt_type == 'prompt_3':
                        length = 3
                    elif data_args.prompt_type == 'prompt_4':
                        length = 4
                    elif data_args.prompt_type == 'prompt_6':
                        length = 6
                    elif data_args.prompt_type == 'prompt_7':
                        length = 7
                    else:
                        length = 5
                    disassemble_logit = disassemble_logits[
                                        img_indice * length:(img_indice + 1) * length]
                    vector = dict()
                    if model_args.eol_type == 'disassembleeol_concrete' or model_args.eol_type == 'disassembleeol_concrete_origin_text' or model_args.eol_type == 'all_disassembleeol_concrete' or model_args.eol_type == 'all_disassembleeol_concrete_origin_text':
                        tokens, values = get_img_valid_disassemble_tokens_values(processor,
                                                                                 disassemble_logit,
                                                                                 vocab_dict,
                                                                                 data_args,
                                                                                 filtered_ids, logit,
                                                                                 model_args)
                    else:
                        tokens, values = get_img_valid_disassemble_tokens_values(processor,
                                                                                 disassemble_logit,
                                                                                 vocab_dict,
                                                                                 data_args,
                                                                                 filtered_ids, None,
                                                                                 model_args)
                    for token, v in zip(tokens, values):
                        if token in vector.keys():
                            if data_args.sparse_value_type == 'replace':
                                vector[token] = int(v)
                            elif data_args.sparse_value_type == 'sum':
                                vector[token] += int(v)
                            else:
                                if int(v) > vector[token]:
                                    vector[token] = int(v)
                        else:
                            vector[token] = int(v)
                    if data_args.sparse_value_mean:
                        for token in vector.keys():
                            if data_args.prompt_type == 'prompt_5':
                                vector[token] //= 5
                            elif data_args.prompt_type == 'prompt_1':
                                vector[token] //= 1
                            elif data_args.prompt_type == 'prompt_2':
                                vector[token] //= 2
                            elif data_args.prompt_type == 'prompt_3':
                                vector[token] //= 3
                            elif data_args.prompt_type == 'prompt_4':
                                vector[token] //= 4
                            elif data_args.prompt_type == 'prompt_6':
                                vector[token] //= 6
                            else:
                                vector[token] //= 7
                    jsonl_data.append(
                        dict(
                            id=id,
                            content="",
                            vector=vector,
                        )
                    )

        for batch_idx, (texts, imgs_path, text_ids, img_ids) in tqdm(enumerate(test_dataloader),
                                                                     total=len(test_dataloader)):
            with torch.cuda.amp.autocast() if training_args.fp16 else nullcontext():
                if len(texts) != data_args.per_device_batch_size:
                    print(len(texts))
                    print(dist.get_rank())

                if 'llava-hf-llava-v1.6-mistral-7b-hf' in model_args.model_name_or_path:

                    if data_args.prompt_type == 'prompt_5':
                        prompt_template = llava_mistral_template_image_prefix
                        if 'concrete' in model_args.eol_type or 'all' not in model_args.eol_type:
                            prompt_template += llava_mistral_template_content_element.format(
                                img_prompt_for_concat)
                        for llava_mistral_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_for_concat:
                            content_element = llava_mistral_template_content_element.format(
                                llava_mistral_retrieval_disassemble_image_prompt)
                            prompt_template += content_element
                    elif data_args.prompt_type == 'prompt_1':
                        prompt_template = llava_mistral_template_image_prefix
                        if 'concrete' in model_args.eol_type or 'all' not in model_args.eol_type:
                            prompt_template += llava_mistral_template_content_element.format(
                                img_prompt_for_concat)
                        for llava_mistral_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_1_for_concat:
                            content_element = llava_mistral_template_content_element.format(
                                llava_mistral_retrieval_disassemble_image_prompt)
                            prompt_template += content_element
                    elif data_args.prompt_type == 'prompt_2':
                        prompt_template = llava_mistral_template_image_prefix
                        if 'concrete' in model_args.eol_type or 'all' not in model_args.eol_type:
                            prompt_template += llava_mistral_template_content_element.format(
                                img_prompt_for_concat)
                        for llava_mistral_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_2_for_concat:
                            content_element = llava_mistral_template_content_element.format(
                                llava_mistral_retrieval_disassemble_image_prompt)
                            prompt_template += content_element
                    elif data_args.prompt_type == 'prompt_3':
                        prompt_template = llava_mistral_template_image_prefix
                        if 'concrete' in model_args.eol_type or 'all' not in model_args.eol_type:
                            prompt_template += llava_mistral_template_content_element.format(
                                img_prompt_for_concat)
                        for llava_mistral_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_3_for_concat:
                            content_element = llava_mistral_template_content_element.format(
                                llava_mistral_retrieval_disassemble_image_prompt)
                            prompt_template += content_element
                    elif data_args.prompt_type == 'prompt_4':
                        prompt_template = llava_mistral_template_image_prefix
                        if 'concrete' in model_args.eol_type or 'all' not in model_args.eol_type:
                            prompt_template += llava_mistral_template_content_element.format(
                                img_prompt_for_concat)
                        for llava_mistral_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_4_for_concat:
                            content_element = llava_mistral_template_content_element.format(
                                llava_mistral_retrieval_disassemble_image_prompt)
                            prompt_template += content_element
                    elif data_args.prompt_type == 'prompt_6':
                        prompt_template = llava_mistral_template_image_prefix
                        if 'concrete' in model_args.eol_type or 'all' not in model_args.eol_type:
                            prompt_template += llava_mistral_template_content_element.format(
                                img_prompt_for_concat)
                        for llava_mistral_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_6_for_concat:
                            content_element = llava_mistral_template_content_element.format(
                                llava_mistral_retrieval_disassemble_image_prompt)
                            prompt_template += content_element
                    elif data_args.prompt_type == 'prompt_7':
                        prompt_template = llava_mistral_template_image_prefix
                        if 'concrete' in model_args.eol_type or 'all' not in model_args.eol_type:
                            prompt_template += llava_mistral_template_content_element.format(
                                img_prompt_for_concat)
                        if data_args.prompt_generation:
                            if data_args.prompt_generation_model == 'llama':
                                for llava_mistral_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_for_concat_llama_generation:
                                    content_element = llava_mistral_template_content_element.format(
                                        llava_mistral_retrieval_disassemble_image_prompt)
                                    prompt_template += content_element
                            else:
                                for llava_mistral_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_for_concat_mistral_generation:
                                    content_element = llava_mistral_template_content_element.format(
                                        llava_mistral_retrieval_disassemble_image_prompt)
                                    prompt_template += content_element
                        else:
                            for llava_mistral_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_7_for_concat:
                                content_element = llava_mistral_template_content_element.format(
                                    llava_mistral_retrieval_disassemble_image_prompt)
                                prompt_template += content_element
                    else:
                        pass

                elif 'llava-hf-llava-v1.6-vicuna-7b-hf' in model_args.model_name_or_path or 'llava-hf-llava-v1.6-vicuna-13b-hf' in model_args.model_name_or_path:
                    if data_args.prompt_type == 'prompt_5':
                        prompt_template = llava_vicuna_template_image_prefix
                        if 'concrete' in model_args.eol_type or 'all' not in model_args.eol_type:
                            prompt_template += llava_vicuna_template_content_element.format(
                                img_prompt_for_concat)
                        for llava_vicuna_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_for_concat:
                            content_element = llava_vicuna_template_content_element.format(
                                llava_vicuna_retrieval_disassemble_image_prompt)
                            prompt_template += content_element
                    elif data_args.prompt_type == 'prompt_1':
                        prompt_template = llava_vicuna_template_image_prefix
                        if 'concrete' in model_args.eol_type or 'all' not in model_args.eol_type:
                            prompt_template += llava_vicuna_template_content_element.format(
                                img_prompt_for_concat)
                        for llava_vicuna_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_1_for_concat:
                            content_element = llava_vicuna_template_content_element.format(
                                llava_vicuna_retrieval_disassemble_image_prompt)
                            prompt_template += content_element
                    elif data_args.prompt_type == 'prompt_2':
                        prompt_template = llava_vicuna_template_image_prefix
                        if 'concrete' in model_args.eol_type or 'all' not in model_args.eol_type:
                            prompt_template += llava_vicuna_template_content_element.format(
                                img_prompt_for_concat)
                        for llava_vicuna_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_2_for_concat:
                            content_element = llava_vicuna_template_content_element.format(
                                llava_vicuna_retrieval_disassemble_image_prompt)
                            prompt_template += content_element
                    elif data_args.prompt_type == 'prompt_3':
                        prompt_template = llava_vicuna_template_image_prefix
                        if 'concrete' in model_args.eol_type or 'all' not in model_args.eol_type:
                            prompt_template += llava_vicuna_template_content_element.format(
                                img_prompt_for_concat)
                        for llava_vicuna_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_3_for_concat:
                            content_element = llava_vicuna_template_content_element.format(
                                llava_vicuna_retrieval_disassemble_image_prompt)
                            prompt_template += content_element
                    elif data_args.prompt_type == 'prompt_4':
                        prompt_template = llava_vicuna_template_image_prefix
                        if 'concrete' in model_args.eol_type or 'all' not in model_args.eol_type:
                            prompt_template += llava_vicuna_template_content_element.format(
                                img_prompt_for_concat)
                        for llava_vicuna_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_4_for_concat:
                            content_element = llava_vicuna_template_content_element.format(
                                llava_vicuna_retrieval_disassemble_image_prompt)
                            prompt_template += content_element
                    elif data_args.prompt_type == 'prompt_6':
                        prompt_template = llava_vicuna_template_image_prefix
                        if 'concrete' in model_args.eol_type or 'all' not in model_args.eol_type:
                            prompt_template += llava_vicuna_template_content_element.format(
                                img_prompt_for_concat)
                        for llava_vicuna_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_6_for_concat:
                            content_element = llava_vicuna_template_content_element.format(
                                llava_vicuna_retrieval_disassemble_image_prompt)
                            prompt_template += content_element
                    elif data_args.prompt_type == 'prompt_7':
                        prompt_template = llava_vicuna_template_image_prefix
                        if 'concrete' in model_args.eol_type or 'all' not in model_args.eol_type:
                            prompt_template += llava_vicuna_template_content_element.format(
                                img_prompt_for_concat)
                        if data_args.prompt_generation:
                            if data_args.prompt_generation_model == 'llama':
                                for llava_vicuna_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_for_concat_llama_generation:
                                    content_element = llava_vicuna_template_content_element.format(
                                        llava_vicuna_retrieval_disassemble_image_prompt)
                                    prompt_template += content_element
                            else:
                                for llava_vicuna_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_for_concat_mistral_generation:
                                    content_element = llava_vicuna_template_content_element.format(
                                        llava_vicuna_retrieval_disassemble_image_prompt)
                                    prompt_template += content_element
                        else:
                            for llava_vicuna_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_7_for_concat:
                                content_element = llava_vicuna_template_content_element.format(
                                    llava_vicuna_retrieval_disassemble_image_prompt)
                                prompt_template += content_element
                    else:
                        pass
                elif 'Qwen2.5-VL-7B-Instruct' in model_args.model_name_or_path:
                    if data_args.prompt_type == 'prompt_5':
                        prompt_template = qwen2_5_template_image_prefix
                        if 'concrete' in model_args.eol_type or 'all' not in model_args.eol_type:
                            prompt_template += qwen2_5_template_content_element.format(
                                img_prompt_for_concat)
                        for qwen2_5_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_for_concat:
                            content_element = qwen2_5_template_content_element.format(
                                qwen2_5_retrieval_disassemble_image_prompt)
                            prompt_template += content_element
                    elif data_args.prompt_type == 'prompt_3':
                        prompt_template = qwen2_5_template_image_prefix
                        if 'concrete' in model_args.eol_type or 'all' not in model_args.eol_type:
                            prompt_template += qwen2_5_template_content_element.format(
                                img_prompt_for_concat)
                        for qwen2_5_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_3_for_concat:
                            content_element = qwen2_5_template_content_element.format(
                                qwen2_5_retrieval_disassemble_image_prompt)
                            prompt_template += content_element
                    elif data_args.prompt_type == 'prompt_7':
                        prompt_template = qwen2_5_template_image_prefix
                        if 'concrete' in model_args.eol_type or 'all' not in model_args.eol_type:
                            prompt_template += qwen2_5_template_content_element.format(
                                img_prompt_for_concat)
                        for qwen2_5_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_7_for_concat:
                            content_element = qwen2_5_template_content_element.format(
                                qwen2_5_retrieval_disassemble_image_prompt)
                            prompt_template += content_element
                elif 'Qwen3-VL-8B-Instruct' in model_args.model_name_or_path:
                    if data_args.prompt_type == 'prompt_5':
                        prompt_template = qwen3_template_image_prefix
                        if 'concrete' in model_args.eol_type or 'all' not in model_args.eol_type:
                            prompt_template += qwen3_template_content_element.format(
                                img_prompt_for_concat)
                        for qwen3_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_for_concat:
                            content_element = qwen3_template_content_element.format(
                                qwen3_retrieval_disassemble_image_prompt)
                            prompt_template += content_element
                    elif data_args.prompt_type == 'prompt_3':
                        prompt_template = qwen3_template_image_prefix
                        if 'concrete' in model_args.eol_type or 'all' not in model_args.eol_type:
                            prompt_template += qwen3_template_content_element.format(
                                img_prompt_for_concat)
                        for qwen3_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_3_for_concat:
                            content_element = qwen3_template_content_element.format(
                                qwen3_retrieval_disassemble_image_prompt)
                            prompt_template += content_element
                    elif data_args.prompt_type == 'prompt_7':
                        prompt_template = qwen3_template_image_prefix
                        if 'concrete' in model_args.eol_type or 'all' not in model_args.eol_type:
                            prompt_template += qwen3_template_content_element.format(
                                img_prompt_for_concat)
                        for qwen3_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_7_for_concat:
                            content_element = qwen3_template_content_element.format(
                                qwen3_retrieval_disassemble_image_prompt)
                            prompt_template += content_element
                    else:
                        pass
                else:
                    if data_args.prompt_type == 'prompt_5':
                        prompt_template = llama3_template_image_prefix
                        if 'concrete' in model_args.eol_type or 'all' not in model_args.eol_type:
                            prompt_template += llama3_template_content_element.format(img_prompt_for_concat)
                        for llama3_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_for_concat:
                            content_element = llama3_template_content_element.format(
                                llama3_retrieval_disassemble_image_prompt)
                            prompt_template += content_element
                    elif data_args.prompt_type == 'prompt_1':
                        prompt_template = llama3_template_image_prefix
                        if 'concrete' in model_args.eol_type or 'all' not in model_args.eol_type:
                            prompt_template += llama3_template_content_element.format(img_prompt_for_concat)
                        for llama3_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_1_for_concat:
                            content_element = llama3_template_content_element.format(
                                llama3_retrieval_disassemble_image_prompt)
                            prompt_template += content_element
                    elif data_args.prompt_type == 'prompt_2':
                        prompt_template = llama3_template_image_prefix
                        if 'concrete' in model_args.eol_type or 'all' not in model_args.eol_type:
                            prompt_template += llama3_template_content_element.format(img_prompt_for_concat)
                        for llama3_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_2_for_concat:
                            content_element = llama3_template_content_element.format(
                                llama3_retrieval_disassemble_image_prompt)
                            prompt_template += content_element
                    elif data_args.prompt_type == 'prompt_3':
                        prompt_template = llama3_template_image_prefix
                        if 'concrete' in model_args.eol_type or 'all' not in model_args.eol_type:
                            prompt_template += llama3_template_content_element.format(img_prompt_for_concat)
                        for llama3_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_3_for_concat:
                            content_element = llama3_template_content_element.format(
                                llama3_retrieval_disassemble_image_prompt)
                            prompt_template += content_element
                    elif data_args.prompt_type == 'prompt_4':
                        prompt_template = llama3_template_image_prefix
                        if 'concrete' in model_args.eol_type or 'all' not in model_args.eol_type:
                            prompt_template += llama3_template_content_element.format(img_prompt_for_concat)
                        for llama3_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_4_for_concat:
                            content_element = llama3_template_content_element.format(
                                llama3_retrieval_disassemble_image_prompt)
                            prompt_template += content_element
                    elif data_args.prompt_type == 'prompt_6':
                        prompt_template = llama3_template_image_prefix
                        if 'concrete' in model_args.eol_type or 'all' not in model_args.eol_type:
                            prompt_template += llama3_template_content_element.format(img_prompt_for_concat)
                        for llama3_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_6_for_concat:
                            content_element = llama3_template_content_element.format(
                                llama3_retrieval_disassemble_image_prompt)
                            prompt_template += content_element
                    elif data_args.prompt_type == 'prompt_7':
                        prompt_template = llama3_template_image_prefix
                        if 'concrete' in model_args.eol_type or 'all' not in model_args.eol_type:
                            prompt_template += llama3_template_content_element.format(img_prompt_for_concat)
                        if data_args.prompt_generation:
                            if data_args.prompt_generation_model == 'llama':
                                for llava_mistral_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_for_concat_llama_generation:
                                    content_element = llama3_template_content_element.format(
                                        llava_mistral_retrieval_disassemble_image_prompt)
                                    prompt_template += content_element
                            else:
                                for llava_mistral_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_for_concat_mistral_generation:
                                    content_element = llama3_template_content_element.format(
                                        llava_mistral_retrieval_disassemble_image_prompt)
                                    prompt_template += content_element
                        else:
                            for llama3_retrieval_disassemble_image_prompt in retrieval_disassemble_image_prompts_7_for_concat:
                                content_element = llama3_template_content_element.format(
                                    llama3_retrieval_disassemble_image_prompt)
                                prompt_template += content_element
                    else:
                        pass
                if training_args.encode_type == 'text':
                    logits, reps = model.encode_data_concat(texts, 'text', processor, device, model_args,
                                                            data_args)
                    if 'disassembleeol_concrete' in model_args.eol_type:
                        disassemble_logits = logits[data_args.per_device_batch_size:]
                        logits = logits[:data_args.per_device_batch_size]
                    elif 'disassembleeol' in model_args.eol_type:
                        disassemble_logits = logits
                else:
                    raw_images = [Image.open(path).convert('RGB') for path in imgs_path]
                    img_inputs = processor(images=raw_images, text=[prompt_template] * len(imgs_path),
                                           return_tensors="pt",
                                           padding=True)
                    imgs = img_inputs.to(device)
                    logits, reps = model.encode_data_concat(imgs, 'image', processor, device, model_args,
                                                            data_args)
                    if 'disassembleeol_concrete' in model_args.eol_type:
                        disassemble_logits = logits[data_args.per_device_batch_size:]
                        logits = logits[:data_args.per_device_batch_size]
                    elif 'disassembleeol' in model_args.eol_type:
                        disassemble_logits = logits

                # print(logits.shape)
                reps = F.normalize(reps, dim=-1)
                if model_args.eol_type == 'all_disassembleeol' or model_args.eol_type == 'all_disassembleeol_origin_text' or model_args.eol_type == 'all_disassembleeol_concrete' or model_args.eol_type == 'all_disassembleeol_concrete_origin_text':
                    if model_args.calculate_type == 'concat':
                        if data_args.prompt_type == 'prompt_5':
                            prompt_length = 5
                        elif data_args.prompt_type == 'prompt_1':
                            prompt_length = 1
                        elif data_args.prompt_type == 'prompt_2':
                            prompt_length = 2
                        elif data_args.prompt_type == 'prompt_3':
                            prompt_length = 3
                        elif data_args.prompt_type == 'prompt_4':
                            prompt_length = 4
                        elif data_args.prompt_type == 'prompt_6':
                            prompt_length = 6
                        elif data_args.prompt_type == 'prompt_7':
                            prompt_length = 7
                        else:
                            prompt_length = 5
                    else:
                        prompt_length = 5
                    reps = reps.reshape(-1, prompt_length, reps.shape[1]).mean(1)
                if training_args.encode_type == 'text':
                    lookup_indices.extend(text_ids)
                else:
                    lookup_indices.extend(img_ids)

                encoded.append(reps.cpu().detach().float().numpy())

                ids = text_ids if training_args.encode_type == 'text' else img_ids
                if training_args.encode_type == 'text':
                    if data_args.sparse_type == 'fusion':
                        for text_indice in range(len(ids)):
                            id = ids[text_indice]
                            if model_args.eol_type == 'disassembleeol_concrete' or model_args.eol_type == 'disassembleeol_concrete_origin_text' or model_args.eol_type == 'all_disassembleeol_concrete' or model_args.eol_type == 'all_disassembleeol_concrete_origin_text':
                                logit = logits[text_indice]
                            text = texts[text_indice]
                            if data_args.prompt_type == 'prompt_5':
                                length = 5
                            elif data_args.prompt_type == 'prompt_1':
                                length = 1
                            elif data_args.prompt_type == 'prompt_2':
                                length = 2
                            elif data_args.prompt_type == 'prompt_3':
                                length = 3
                            elif data_args.prompt_type == 'prompt_4':
                                length = 4
                            elif data_args.prompt_type == 'prompt_6':
                                length = 6
                            elif data_args.prompt_type == 'prompt_7':
                                length = 7
                            else:
                                length = 5
                            disassemble_logit = disassemble_logits[
                                                text_indice * length:(text_indice + 1) * length]
                            vector = dict()
                            if model_args.eol_type == 'disassembleeol_concrete' or model_args.eol_type == 'disassembleeol_concrete_origin_text' or model_args.eol_type == 'all_disassembleeol_concrete' or model_args.eol_type == 'all_disassembleeol_concrete_origin_text':
                                tokens, values = get_text_valid_disassemble_tokens_values_fusion(text,
                                                                                                 processor.tokenizer,
                                                                                                 disassemble_logit,
                                                                                                 vocab_dict,
                                                                                                 data_args,
                                                                                                 filtered_ids,
                                                                                                 'guess', logit,
                                                                                                 model_args)
                            else:
                                tokens, values = get_text_valid_disassemble_tokens_values_fusion(text,
                                                                                                 processor.tokenizer,
                                                                                                 disassemble_logit,
                                                                                                 vocab_dict,
                                                                                                 data_args,
                                                                                                 filtered_ids,
                                                                                                 'guess', None,
                                                                                                 model_args)

                            for token, v in zip(tokens, values):
                                if token in vector.keys():
                                    if data_args.sparse_value_type == 'replace':
                                        vector[token] = int(v)
                                    elif data_args.sparse_value_type == 'sum':
                                        vector[token] += int(v)
                                    else:
                                        if int(v) > vector[token]:
                                            vector[token] = int(v)
                                else:
                                    vector[token] = int(v)
                            if data_args.sparse_value_mean:
                                for token in vector.keys():
                                    if data_args.prompt_type == 'prompt_5':
                                        vector[token] //= 5
                                    elif data_args.prompt_type == 'prompt_1':
                                        vector[token] //= 1
                                    elif data_args.prompt_type == 'prompt_2':
                                        vector[token] //= 2
                                    elif data_args.prompt_type == 'prompt_3':
                                        vector[token] //= 3
                                    elif data_args.prompt_type == 'prompt_4':
                                        vector[token] //= 4
                                    elif data_args.prompt_type == 'prompt_6':
                                        vector[token] //= 6
                                    else:
                                        vector[token] //= 7
                            if model_args.eol_type == 'disassembleeol_concrete' or model_args.eol_type == 'disassembleeol_concrete_origin_text' or model_args.eol_type == 'all_disassembleeol_concrete' or model_args.eol_type == 'all_disassembleeol_concrete_origin_text':
                                tokens, values = get_text_valid_disassemble_tokens_values_fusion(text,
                                                                                                 processor.tokenizer,
                                                                                                 disassemble_logit,
                                                                                                 vocab_dict,
                                                                                                 data_args,
                                                                                                 filtered_ids,
                                                                                                 'origin_text',
                                                                                                 logit,
                                                                                                 model_args)
                            else:
                                tokens, values = get_text_valid_disassemble_tokens_values_fusion(text,
                                                                                                 processor.tokenizer,
                                                                                                 disassemble_logit,
                                                                                                 vocab_dict,
                                                                                                 data_args,
                                                                                                 filtered_ids,
                                                                                                 'origin_text',
                                                                                                 None,
                                                                                                 model_args)
                            for token, v in zip(tokens, values):
                                if token in vector.keys():
                                    if data_args.sparse_value_type == 'replace':
                                        vector[token] = int(v)
                                    elif data_args.sparse_value_type == 'sum':
                                        vector[token] += int(v)
                                    else:
                                        if int(v) > vector[token]:
                                            vector[token] = int(v)
                                else:
                                    vector[token] = int(v)
                            jsonl_data.append(
                                dict(
                                    id=id,
                                    content="",
                                    vector=vector,
                                )
                            )
                    else:
                        for text_indice in range(len(ids)):
                            id = ids[text_indice]
                            if model_args.eol_type == 'disassembleeol_concrete' or model_args.eol_type == 'disassembleeol_concrete_origin_text' or model_args.eol_type == 'all_disassembleeol_concrete' or model_args.eol_type == 'all_disassembleeol_concrete_origin_text':
                                logit = logits[text_indice]
                            text = texts[text_indice]
                            if data_args.prompt_type == 'prompt_5':
                                length = 5
                            elif data_args.prompt_type == 'prompt_1':
                                length = 1
                            elif data_args.prompt_type == 'prompt_2':
                                length = 2
                            elif data_args.prompt_type == 'prompt_3':
                                length = 3
                            elif data_args.prompt_type == 'prompt_4':
                                length = 4
                            elif data_args.prompt_type == 'prompt_6':
                                length = 6
                            elif data_args.prompt_type == 'prompt_7':
                                length = 7
                            else:
                                length = 5
                            disassemble_logit = disassemble_logits[
                                                text_indice * length:(text_indice + 1) * length]
                            vector = dict()
                            if model_args.eol_type == 'disassembleeol_concrete' or model_args.eol_type == 'disassembleeol_concrete_origin_text' or model_args.eol_type == 'all_disassembleeol_concrete' or model_args.eol_type == 'all_disassembleeol_concrete_origin_text':
                                tokens, values = get_text_valid_disassemble_tokens_values(text,
                                                                                          processor.tokenizer,
                                                                                          disassemble_logit,
                                                                                          vocab_dict,
                                                                                          data_args,
                                                                                          filtered_ids, logit,
                                                                                          model_args)
                            else:
                                tokens, values = get_text_valid_disassemble_tokens_values(text,
                                                                                          processor.tokenizer,
                                                                                          disassemble_logit,
                                                                                          vocab_dict,
                                                                                          data_args,
                                                                                          filtered_ids, None,
                                                                                          model_args)

                            for token, v in zip(tokens, values):
                                if token in vector.keys():
                                    if data_args.sparse_value_type == 'replace':
                                        vector[token] = int(v)
                                    elif data_args.sparse_value_type == 'sum':
                                        vector[token] += int(v)
                                    else:
                                        if int(v) > vector[token]:
                                            vector[token] = int(v)
                                else:
                                    vector[token] = int(v)
                            if data_args.sparse_value_mean:
                                for token in vector.keys():
                                    if data_args.prompt_type == 'prompt_5':
                                        vector[token] //= 5
                                    elif data_args.prompt_type == 'prompt_1':
                                        vector[token] //= 1
                                    elif data_args.prompt_type == 'prompt_2':
                                        vector[token] //= 2
                                    elif data_args.prompt_type == 'prompt_3':
                                        vector[token] //= 3
                                    elif data_args.prompt_type == 'prompt_4':
                                        vector[token] //= 4
                                    elif data_args.prompt_type == 'prompt_6':
                                        vector[token] //= 6
                                    else:
                                        vector[token] //= 7
                            jsonl_data.append(
                                dict(
                                    id=id,
                                    content="",
                                    vector=vector,
                                )
                            )
                else:
                    for img_indice in range(len(ids)):
                        id = ids[img_indice]
                        if model_args.eol_type == 'disassembleeol_concrete' or model_args.eol_type == 'disassembleeol_concrete_origin_text' or model_args.eol_type == 'all_disassembleeol_concrete' or model_args.eol_type == 'all_disassembleeol_concrete_origin_text':
                            logit = logits[img_indice]
                        text = texts[img_indice]
                        if data_args.prompt_type == 'prompt_5':
                            length = 5
                        elif data_args.prompt_type == 'prompt_1':
                            length = 1
                        elif data_args.prompt_type == 'prompt_2':
                            length = 2
                        elif data_args.prompt_type == 'prompt_3':
                            length = 3
                        elif data_args.prompt_type == 'prompt_4':
                            length = 4
                        elif data_args.prompt_type == 'prompt_6':
                            length = 6
                        elif data_args.prompt_type == 'prompt_7':
                            length = 7
                        else:
                            length = 5
                        disassemble_logit = disassemble_logits[
                                            img_indice * length:(img_indice + 1) * length]
                        vector = dict()
                        if model_args.eol_type == 'disassembleeol_concrete' or model_args.eol_type == 'disassembleeol_concrete_origin_text' or model_args.eol_type == 'all_disassembleeol_concrete' or model_args.eol_type == 'all_disassembleeol_concrete_origin_text':
                            tokens, values = get_img_valid_disassemble_tokens_values(processor,
                                                                                     disassemble_logit,
                                                                                     vocab_dict,
                                                                                     data_args,
                                                                                     filtered_ids, logit,
                                                                                     model_args)
                        else:
                            tokens, values = get_img_valid_disassemble_tokens_values(processor,
                                                                                     disassemble_logit,
                                                                                     vocab_dict,
                                                                                     data_args,
                                                                                     filtered_ids, None,
                                                                                     model_args)
                        for token, v in zip(tokens, values):
                            if token in vector.keys():
                                if data_args.sparse_value_type == 'replace':
                                    vector[token] = int(v)
                                elif data_args.sparse_value_type == 'sum':
                                    vector[token] += int(v)
                                else:
                                    if int(v) > vector[token]:
                                        vector[token] = int(v)
                            else:
                                vector[token] = int(v)
                        if data_args.sparse_value_mean:
                            for token in vector.keys():
                                if data_args.prompt_type == 'prompt_5':
                                    vector[token] //= 5
                                elif data_args.prompt_type == 'prompt_1':
                                    vector[token] //= 1
                                elif data_args.prompt_type == 'prompt_2':
                                    vector[token] //= 2
                                elif data_args.prompt_type == 'prompt_3':
                                    vector[token] //= 3
                                elif data_args.prompt_type == 'prompt_4':
                                    vector[token] //= 4
                                elif data_args.prompt_type == 'prompt_6':
                                    vector[token] //= 6
                                else:
                                    vector[token] //= 7
                        jsonl_data.append(
                            dict(
                                id=id,
                                content="",
                                vector=vector,
                            )
                        )

    encoded = np.concatenate(encoded)

    print(f'rank:{dist.get_rank()}, encoded length:{len(encoded)}')
    print(f'rank:{dist.get_rank()}, lookup_indices:{len(lookup_indices)}')
    print(f'rank:{dist.get_rank()}, jsonl_data:{len(jsonl_data)}')

    if data_args.is_filtered:
        filtered = "filter"
    else:
        filtered = "no_filter"

    if data_args.sparse_manual:
        manual = 'manual'
    else:
        manual = "no_manual"

    if model_args.use_output_embedding_cluster:
        cluster = f'cluster_{model_args.cluster_sum}'
    else:
        cluster = 'no_cluster'

    if data_args.sparse_value_mean:
        use_sparse_value_mean = 'mean'
    else:
        use_sparse_value_mean = 'no_mean'

    print(
        f'{data_args.dense_output_dir}/{model_args.model_name_or_path[14:]}/{data_args.dataset_name}/{training_args.encode_type}/{filtered}/{model_args.calculate_type}/{data_args.prompt_type}/{data_args.dataset_split}/{data_args.num_expended_tokens}_{manual}_{data_args.sparse_length}_{data_args.sparse_value_type}_{cluster}_{data_args.reps_loc}_{model_args.eol_type}_{data_args.sparse_lower_or_upper}_{use_sparse_value_mean}_ood')
    os.makedirs(
        f'{data_args.dense_output_dir}/{model_args.model_name_or_path[14:]}/{data_args.dataset_name}/{training_args.encode_type}/{filtered}/{model_args.calculate_type}/{data_args.prompt_type}/{data_args.dataset_split}/{data_args.num_expended_tokens}_{manual}_{data_args.sparse_length}_{data_args.sparse_value_type}_{cluster}_{data_args.reps_loc}_{model_args.eol_type}_{data_args.sparse_lower_or_upper}_{use_sparse_value_mean}_ood',
        exist_ok=True)
    os.makedirs(
        f'{data_args.sparse_output_dir}/{model_args.model_name_or_path[14:]}/{data_args.dataset_name}/{training_args.encode_type}/{filtered}/{model_args.calculate_type}/{data_args.prompt_type}/{data_args.dataset_split}/{data_args.num_expended_tokens}_{manual}_{data_args.sparse_length}_{data_args.sparse_value_type}_{cluster}_{data_args.reps_loc}_{model_args.eol_type}_{data_args.sparse_lower_or_upper}_{use_sparse_value_mean}_ood',
        exist_ok=True)

    with open(os.path.join(
            f'{data_args.dense_output_dir}/{model_args.model_name_or_path[14:]}/{data_args.dataset_name}/{training_args.encode_type}/{filtered}/{model_args.calculate_type}/{data_args.prompt_type}/{data_args.dataset_split}/{data_args.num_expended_tokens}_{manual}_{data_args.sparse_length}_{data_args.sparse_value_type}_{cluster}_{data_args.reps_loc}_{model_args.eol_type}_{data_args.sparse_lower_or_upper}_{use_sparse_value_mean}_ood',
            f'query.pkl') if data_args.encode_is_query else os.path.join(
        f'{data_args.dense_output_dir}/{model_args.model_name_or_path[14:]}/{data_args.dataset_name}/{training_args.encode_type}/{filtered}/{model_args.calculate_type}/{data_args.prompt_type}/{data_args.dataset_split}/{data_args.num_expended_tokens}_{manual}_{data_args.sparse_length}_{data_args.sparse_value_type}_{cluster}_{data_args.reps_loc}_{model_args.eol_type}_{data_args.sparse_lower_or_upper}_{use_sparse_value_mean}_ood',
        f'corpus_{dist.get_rank()}.pkl'), 'wb') as f:
        pickle.dump((encoded, lookup_indices), f)

    with open(os.path.join(
            f'{data_args.sparse_output_dir}/{model_args.model_name_or_path[14:]}/{data_args.dataset_name}/{training_args.encode_type}/{filtered}/{model_args.calculate_type}/{data_args.prompt_type}/{data_args.dataset_split}/{data_args.num_expended_tokens}_{manual}_{data_args.sparse_length}_{data_args.sparse_value_type}_{cluster}_{data_args.reps_loc}_{model_args.eol_type}_{data_args.sparse_lower_or_upper}_{use_sparse_value_mean}_ood',
            f'query.tsv') if data_args.encode_is_query else os.path.join(
        f'{data_args.sparse_output_dir}/{model_args.model_name_or_path[14:]}/{data_args.dataset_name}/{training_args.encode_type}/{filtered}/{model_args.calculate_type}/{data_args.prompt_type}/{data_args.dataset_split}/{data_args.num_expended_tokens}_{manual}_{data_args.sparse_length}_{data_args.sparse_value_type}_{cluster}_{data_args.reps_loc}_{model_args.eol_type}_{data_args.sparse_lower_or_upper}_{use_sparse_value_mean}_ood',
        f'corpus_{dist.get_rank()}.jsonl'), 'w') as f:
        for data in jsonl_data:
            if data_args.encode_is_query:
                id = data['id']
                vector = data['vector']
                query = " ".join([" ".join([str(token)] * freq) for token, freq in vector.items()])
                if len(query.strip()) == 0:
                    continue
                f.write(f'{id}\t{query}\n')
            else:
                f.write(json.dumps(data) + "\n")


    # 训练结束后添加同步屏障
    dist.barrier()

    # 确保所有进程同步退出
    if dist.get_rank() == 0:
        # 主进程最后退出
        torch.distributed.destroy_process_group()
    else:
        torch.distributed.destroy_process_group()


if __name__ == "__main__":
    main()
